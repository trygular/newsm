-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.1.73


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema NewsMedia
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ NewsMedia;
USE NewsMedia;

--
-- Table structure for table `NewsMedia`.`NewData`
--

DROP TABLE IF EXISTS `NewData`;
CREATE TABLE `NewData` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(45) NOT NULL DEFAULT '',
  `subname` varchar(45) NOT NULL DEFAULT '',
  `gender` varchar(45) NOT NULL DEFAULT '',
  `mobno` varchar(45) NOT NULL DEFAULT '',
  `address` longtext NOT NULL,
  `occupation` varchar(45) NOT NULL DEFAULT '',
  `suggestion` varchar(100) NOT NULL DEFAULT '',
  `email` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`NewData`
--

/*!40000 ALTER TABLE `NewData` DISABLE KEYS */;
/*!40000 ALTER TABLE `NewData` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`NewData1`
--

DROP TABLE IF EXISTS `NewData1`;
CREATE TABLE `NewData1` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `interest` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`NewData1`
--

/*!40000 ALTER TABLE `NewData1` DISABLE KEYS */;
/*!40000 ALTER TABLE `NewData1` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`NewsMaster`
--

DROP TABLE IF EXISTS `NewsMaster`;
CREATE TABLE `NewsMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `newsname` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`NewsMaster`
--

/*!40000 ALTER TABLE `NewsMaster` DISABLE KEYS */;
INSERT INTO `NewsMaster` (`id`,`newsname`,`active`) VALUES 
 (1,'NEWS',1),
 (2,'CRIME',1),
 (3,'EVENT',1),
 (4,'INTERVIEW',1),
 (5,'ACCIDENT',1),
 (6,'REPORT',1),
 (7,'DOCUMENT',1),
 (8,'NATIONAL NEWS',1);
/*!40000 ALTER TABLE `NewsMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`OccupationMaster`
--

DROP TABLE IF EXISTS `OccupationMaster`;
CREATE TABLE `OccupationMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`OccupationMaster`
--

/*!40000 ALTER TABLE `OccupationMaster` DISABLE KEYS */;
/*!40000 ALTER TABLE `OccupationMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`PriorityMaster`
--

DROP TABLE IF EXISTS `PriorityMaster`;
CREATE TABLE `PriorityMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`PriorityMaster`
--

/*!40000 ALTER TABLE `PriorityMaster` DISABLE KEYS */;
INSERT INTO `PriorityMaster` (`id`,`name`,`active`) VALUES 
 (1,'HIGH',1),
 (2,'LOW',1),
 (3,'NORMAL',1);
/*!40000 ALTER TABLE `PriorityMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`SectorMaster`
--

DROP TABLE IF EXISTS `SectorMaster`;
CREATE TABLE `SectorMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sector` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`SectorMaster`
--

/*!40000 ALTER TABLE `SectorMaster` DISABLE KEYS */;
INSERT INTO `SectorMaster` (`id`,`sector`,`active`) VALUES 
 (1,'GENERAL',1),
 (2,'SOCIAL',1),
 (3,'CRIME',1),
 (4,'ACCIDENT',1),
 (5,' CITY CORPORATION',1),
 (6,'KSRTC',1),
 (7,'RAILWAY',1),
 (8,'AUTO MOBILES',1),
 (9,'EDUCATIONAL',1),
 (10,'FUNCTION',1),
 (11,'EXBIHITION',1),
 (12,'INFORMATION',1),
 (13,'INFO TECH',1),
 (14,'NATIONAL',1),
 (15,'WOMEN AND CHILDREN',1),
 (16,'HEALTH',1),
 (17,'AGRICULTURAL',1),
 (18,'FESTIVAL',1),
 (19,'TRADITIONAL',1),
 (20,'CLUTURAL',1),
 (21,'SPORT',1),
 (22,'CORPORATION',1),
 (23,'WILDLIFE',1),
 (24,'COMPITATION',1);
/*!40000 ALTER TABLE `SectorMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`SourceMaster`
--

DROP TABLE IF EXISTS `SourceMaster`;
CREATE TABLE `SourceMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `source` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`SourceMaster`
--

/*!40000 ALTER TABLE `SourceMaster` DISABLE KEYS */;
INSERT INTO `SourceMaster` (`id`,`source`,`active`) VALUES 
 (2,'BELGAUM REPORTING',1),
 (3,'SMT BELGAUM',1),
 (4,'SMT MUMBAI',1),
 (5,'SMT PUNE',1),
 (6,'SMT GOA',1),
 (7,'SMT SINDHUDURAG',1),
 (8,'SMT KOLHAPUR',1),
 (9,'SMT SANGALI',1),
 (10,'SMT SATARA',1),
 (11,'SMT RATNAGIRI',1);
/*!40000 ALTER TABLE `SourceMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`StatusMaster`
--

DROP TABLE IF EXISTS `StatusMaster`;
CREATE TABLE `StatusMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`StatusMaster`
--

/*!40000 ALTER TABLE `StatusMaster` DISABLE KEYS */;
INSERT INTO `StatusMaster` (`id`,`status`,`active`) VALUES 
 (1,'COMPLETE',1),
 (2,'PENDING',1),
 (3,'IN PROCESS',1);
/*!40000 ALTER TABLE `StatusMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`StatusTaskMaster`
--

DROP TABLE IF EXISTS `StatusTaskMaster`;
CREATE TABLE `StatusTaskMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `status` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`StatusTaskMaster`
--

/*!40000 ALTER TABLE `StatusTaskMaster` DISABLE KEYS */;
INSERT INTO `StatusTaskMaster` (`id`,`status`,`active`) VALUES 
 (1,'COMPLETE',1),
 (2,'PENDING',1),
 (3,'IN PROCESS',1);
/*!40000 ALTER TABLE `StatusTaskMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TaskAssignMaster`
--

DROP TABLE IF EXISTS `TaskAssignMaster`;
CREATE TABLE `TaskAssignMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TaskAssignMaster`
--

/*!40000 ALTER TABLE `TaskAssignMaster` DISABLE KEYS */;
INSERT INTO `TaskAssignMaster` (`id`,`name`) VALUES 
 (1,'SACHIN MALAVI'),
 (2,'TOUSIF MUJAWAR'),
 (3,'ROHAN PATIL'),
 (4,'ROHIT  KHOT'),
 (5,'AKSHATA NAIK'),
 (6,'NIKITA ASHTEKAR'),
 (7,'TEJASWINI PATIL'),
 (8,'NILIMA LOHAR'),
 (9,'VIJAY NIMBALKAR'),
 (10,'UPENDRA BAJIKAR'),
 (19,'ABHISHEK BHOSALE'),
 (12,'SELF'),
 (13,'P.K.GUNJIKAR'),
 (14,'AMRUT BIRJE'),
 (15,'GIRISH KALLED'),
 (16,'ANANT KANGRALKAR'),
 (17,'JAGDISH DADDIKAR'),
 (18,'SHUBHAM VAGHAVDEKAR'),
 (20,'ASMITA KANGRALKAR'),
 (21,'RADHIKA SAMBREKAR'),
 (22,'RAVI MALSHET'),
 (23,'YUVRAJ PATIL'),
 (24,'ANNAPPA PATIL'),
 (25,'MANISHA SUBEDAR'),
 (26,'NMS'),
 (27,'PRASHANT CHAVAN'),
 (28,'HIMANSHU '),
 (29,'SAMBHAJI BHISE'),
 (30,'PRASAD PRABHU'),
 (31,'SUNIL RAJGOLKAR'),
 (32,'KUMAR'),
 (33,'SUSHANT KURANGI'),
 (34,'RAMESH HIREMATH');
/*!40000 ALTER TABLE `TaskAssignMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TaskAssignMaster1`
--

DROP TABLE IF EXISTS `TaskAssignMaster1`;
CREATE TABLE `TaskAssignMaster1` (
  `id` int(10) unsigned DEFAULT NULL,
  `typename` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TaskAssignMaster1`
--

/*!40000 ALTER TABLE `TaskAssignMaster1` DISABLE KEYS */;
INSERT INTO `TaskAssignMaster1` (`id`,`typename`) VALUES 
 (1,'2'),
 (1,'3'),
 (1,'4'),
 (1,'5'),
 (3,'2'),
 (3,'3'),
 (3,'4'),
 (3,'5'),
 (7,'2'),
 (7,'4'),
 (7,'5'),
 (8,'1'),
 (8,'2'),
 (8,'5'),
 (2,'3'),
 (2,'4'),
 (2,'6'),
 (4,'3'),
 (4,'4'),
 (4,'6'),
 (5,'2'),
 (5,'4'),
 (5,'5'),
 (5,'6'),
 (6,'2'),
 (6,'4'),
 (6,'5'),
 (6,'6'),
 (9,'1'),
 (9,'6'),
 (10,'1'),
 (11,'5'),
 (12,'1'),
 (12,'2'),
 (12,'3'),
 (12,'4'),
 (12,'5'),
 (12,'6'),
 (13,'6'),
 (14,'6'),
 (15,'1'),
 (16,'1'),
 (17,'6'),
 (18,'3'),
 (18,'4'),
 (18,'6'),
 (19,'4'),
 (19,'6'),
 (20,'1'),
 (21,'1'),
 (22,'1'),
 (23,'1'),
 (23,'6'),
 (24,'1'),
 (24,'6'),
 (25,'1'),
 (26,'1'),
 (26,'5'),
 (27,'1'),
 (28,'2'),
 (29,'6'),
 (30,'1'),
 (31,'1'),
 (32,'6'),
 (33,'6'),
 (33,'1'),
 (34,'1');
/*!40000 ALTER TABLE `TaskAssignMaster1` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TaskStatusMaster`
--

DROP TABLE IF EXISTS `TaskStatusMaster`;
CREATE TABLE `TaskStatusMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `source` varchar(100) NOT NULL DEFAULT '',
  `team` varchar(100) NOT NULL DEFAULT '',
  `pdate` date NOT NULL DEFAULT '0000-00-00',
  `newstype` varchar(100) NOT NULL DEFAULT '',
  `videotime` time NOT NULL DEFAULT '00:00:00',
  `sector` varchar(45) NOT NULL DEFAULT '',
  `priority` varchar(45) NOT NULL DEFAULT '',
  `remark` longtext NOT NULL,
  `status` varchar(45) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TaskStatusMaster`
--

/*!40000 ALTER TABLE `TaskStatusMaster` DISABLE KEYS */;
INSERT INTO `TaskStatusMaster` (`id`,`name`,`sdate`,`source`,`team`,`pdate`,`newstype`,`videotime`,`sector`,`priority`,`remark`,`status`) VALUES 
 (1,'Malingon','2017-07-31','5','1','2017-07-31','1','00:07:00','1','1','','1'),
 (2,'Divanga Ketan Lohar','2017-07-31','2','1','2017-07-31','1','00:03:24','1','1','','1'),
 (3,'Dolby Ban','2017-07-31','2','1','2017-07-31','1','00:05:07','1','1','','1'),
 (4,'Tattoo','2017-07-31','2','1','2017-07-31','1','00:04:36','1','1','','1'),
 (5,'R Ramchandran','2017-08-01','2','1','2017-08-01','1','00:02:08','1','1','','1'),
 (6,'koyana News','2017-07-31','2','1','2017-08-01','1','00:03:50','1','3','','1'),
 (7,'Chate Education Class News','2017-07-31','2','2','0000-00-00','1','00:00:00','1','3','','1'),
 (8,'Vaijanath Mandir News','2017-07-31','2','2','2017-08-01','1','00:00:00','1','3','','1'),
 (9,'Art Exibition','2017-08-01','3','1','2017-08-01','1','00:01:46','11','1','','1'),
 (10,'Post Stamp  Exibition','2017-08-01','3','1','2017-08-01','1','00:03:16','11','1','','1'),
 (11,'Save Water (Arati Bhandri)','2017-08-01','2','2','2017-08-01','1','00:04:50','1','1','','1');
INSERT INTO `TaskStatusMaster` (`id`,`name`,`sdate`,`source`,`team`,`pdate`,`newstype`,`videotime`,`sector`,`priority`,`remark`,`status`) VALUES 
 (12,'Lakkannavar','2017-08-01','3','1','2017-08-01','1','00:03:21','1','1','','1'),
 (13,'Vaijanath (mama)','2017-08-01','2','1','2017-08-01','1','00:04:40','1','1','','1'),
 (14,'Ekyana (Railway Station)','2017-08-02','2','2','2017-08-02','1','00:04:05','1','1','','1'),
 (15,'Idea (Jio)','2017-07-31','3','1','2017-08-02','1','00:01:39','1','3','','1'),
 (16,'Fedding India (Doc)','2017-08-02','3','1','2017-08-02','7','00:04:05','1','1','','1'),
 (17,'Sanjoyt Bandekar / Nivedan','2017-08-02','2','2','2017-08-02','1','00:03:57','22','1','','1'),
 (18,'Dharmveer Sambhaji chowk accident','2017-08-02','2','2','2017-08-02','1','00:01:19','4','1','','1'),
 (19,'Battishi Lhirala','2017-07-27','2','2','2017-07-27','1','00:02:10','1','1','','1'),
 (20,'Ballari Nala','2017-08-03','2','2','2017-08-03','1','00:02:41','3','1','','1'),
 (21,'Mahila Jagruti Yoga','2017-08-03','3','1','2017-08-03','1','00:05:42','2','1','','1'),
 (22,'Mahila Ganesh Interview','2017-08-03','2','2','2017-08-03','1','00:05:13','20','1','','1');
INSERT INTO `TaskStatusMaster` (`id`,`name`,`sdate`,`source`,`team`,`pdate`,`newstype`,`videotime`,`sector`,`priority`,`remark`,`status`) VALUES 
 (23,'Gomas Illegal Supply','2017-08-04','2','2','2017-08-04','1','00:02:12','1','1','','1'),
 (24,'Traffic Police','2017-08-03','2','2','2017-08-03','1','00:02:41','1','1','','1'),
 (25,'Mysore intallegent transport System','2017-08-03','3','1','2017-08-04','7','00:06:10','12','1','','1'),
 (26,'Raksha Bandhan ','2017-08-03','3','1','2017-08-04','1','00:06:06','20','1','','1'),
 (27,'Rakesh Sippi','2017-08-04','2','2','2017-08-04','1','00:04:05','1','1','','1'),
 (28,'speed news','2017-10-11','3','1','2017-10-11','8','00:02:38','1','1','','1'),
 (29,'crime news','2017-10-11','3','1','2017-10-11','1','00:02:12','3','1','','1'),
 (30,'BHUSAMPADAN NUKSAN','2017-10-10','2','2','2017-10-11','1','00:03:53','1','3','','1'),
 (31,'DIWALI FARAL TAYARI','2017-10-10','3','1','2017-10-11','6','00:05:50','18','3','','1'),
 (32,'VEHICAL INCREASE','2017-10-09','2','1','2017-10-11','1','00:05:21','1','3','','1'),
 (33,'DIWALI KANDIL','2017-10-11','2','1','2017-10-11','6','00:05:40','18','1','','1');
INSERT INTO `TaskStatusMaster` (`id`,`name`,`sdate`,`source`,`team`,`pdate`,`newstype`,`videotime`,`sector`,`priority`,`remark`,`status`) VALUES 
 (34,'CONTENAR','2017-10-11','3','1','2017-10-11','1','00:01:01','1','1','','1'),
 (35,'MAHAMANTHANA','2017-10-11','3','1','2017-10-11','7','00:03:26','2','1','','1'),
 (36,'SPEED NEWS','2017-10-12','3','1','2017-10-12','8','00:00:00','12','1','','1'),
 (37,'OX COMPITATION','2017-10-12','2','1','2017-10-17','1','00:02:55','23','1','','1'),
 (38,'CRIME NEWS','2017-10-12','3','1','2017-10-12','2','00:02:37','3','1','','1'),
 (39,'HADAGA','2017-10-11','2','2','2017-10-12','6','00:01:55','10','3','','1'),
 (40,'ADOPT ','2017-10-12','3','1','2017-10-12','1','00:02:35','15','1','','1'),
 (41,'RAILWAY ROAD','2017-10-11','2','2','2017-10-12','1','00:01:54','7','3','','1'),
 (42,'SHASTRI NAGAR  HADAGA','2017-10-10','3','1','2017-10-12','6','00:08:31','10','1','','1'),
 (43,'B.K.COLLAGE','2017-10-12','2','2','2017-10-12','1','00:05:50','9','1','','1'),
 (44,'LANDON  VADAPAV','2017-10-10','3','1','2017-10-12','7','00:03:26','1','1','','1');
INSERT INTO `TaskStatusMaster` (`id`,`name`,`sdate`,`source`,`team`,`pdate`,`newstype`,`videotime`,`sector`,`priority`,`remark`,`status`) VALUES 
 (45,'KOLHAPUR KANYA','2017-10-12','2','2','2017-10-12','1','00:04:05','1','1','','1'),
 (46,'DHOL-TASHA PATAHK LOKAMAY','2017-10-12','2','2','2017-10-12','1','00:05:04','24','1','','1'),
 (47,'BIMS','2017-10-10','2','2','2017-10-12','1','00:02:23','16','3','','1');
/*!40000 ALTER TABLE `TaskStatusMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TaskStatusMaster1`
--

DROP TABLE IF EXISTS `TaskStatusMaster1`;
CREATE TABLE `TaskStatusMaster1` (
  `id` int(10) unsigned DEFAULT NULL,
  `tasktype` varchar(100) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TaskStatusMaster1`
--

/*!40000 ALTER TABLE `TaskStatusMaster1` DISABLE KEYS */;
INSERT INTO `TaskStatusMaster1` (`id`,`tasktype`,`name`) VALUES 
 (1,'1','27'),
 (1,'2','28'),
 (1,'3','3'),
 (1,'4','4'),
 (1,'5','12'),
 (1,'6','12'),
 (2,'1','21'),
 (2,'2','3'),
 (2,'3','1'),
 (2,'4','4'),
 (2,'5','12'),
 (2,'6','12'),
 (3,'1','26'),
 (3,'2','3'),
 (3,'3','1'),
 (3,'4','4'),
 (3,'5','12'),
 (3,'6','12'),
 (4,'1','Select'),
 (4,'2','Select'),
 (4,'3','1'),
 (4,'4','4'),
 (4,'5','Select'),
 (4,'6','Select'),
 (5,'1','12'),
 (5,'2','5'),
 (5,'3','1'),
 (5,'4','4'),
 (5,'5','Select'),
 (5,'6','Select'),
 (6,'1','12'),
 (6,'2','3'),
 (6,'3','3'),
 (6,'4','4'),
 (6,'5','Select'),
 (6,'6','29'),
 (7,'1','Select'),
 (7,'2','3'),
 (7,'3','3'),
 (7,'4','4'),
 (7,'5','Select'),
 (7,'6','Select'),
 (8,'1','26'),
 (8,'2','3'),
 (8,'3','3'),
 (8,'4','4'),
 (8,'5','12'),
 (8,'6','Select'),
 (9,'1','26'),
 (9,'2','5'),
 (9,'3','3'),
 (9,'4','4'),
 (9,'5','26'),
 (9,'6','9'),
 (10,'1','20'),
 (10,'2','3'),
 (10,'3','3'),
 (10,'4','4'),
 (10,'5','26'),
 (10,'6','9'),
 (11,'1','12'),
 (11,'2','5');
INSERT INTO `TaskStatusMaster1` (`id`,`tasktype`,`name`) VALUES 
 (11,'3','1'),
 (11,'4','4'),
 (11,'5','12'),
 (11,'6','13'),
 (12,'1','12'),
 (12,'2','5'),
 (12,'3','1'),
 (12,'4','4'),
 (12,'5','26'),
 (12,'6','Select'),
 (13,'1','26'),
 (13,'2','5'),
 (13,'3','1'),
 (13,'4','4'),
 (13,'5','Select'),
 (13,'6','Select'),
 (14,'1','30'),
 (14,'2','5'),
 (14,'3','3'),
 (14,'4','4'),
 (14,'5','26'),
 (14,'6','14'),
 (15,'1','12'),
 (15,'2','5'),
 (15,'3','3'),
 (15,'4','4'),
 (15,'5','26'),
 (15,'6','12'),
 (16,'1','12'),
 (16,'2','3'),
 (16,'3','3'),
 (16,'4','4'),
 (16,'5','7'),
 (16,'6','12'),
 (17,'1','10'),
 (17,'2','3'),
 (17,'3','1'),
 (17,'4','4'),
 (17,'5','26'),
 (17,'6','14'),
 (18,'1','10'),
 (18,'2','3'),
 (18,'3','3'),
 (18,'4','4'),
 (18,'5','12'),
 (18,'6','14'),
 (19,'1','30'),
 (19,'2','1'),
 (19,'3','1'),
 (19,'4','1'),
 (19,'5','12'),
 (19,'6','12'),
 (20,'1','31'),
 (20,'2','3'),
 (20,'3','3'),
 (20,'4','4'),
 (20,'5','12'),
 (20,'6','13'),
 (21,'1','12'),
 (21,'2','3'),
 (21,'3','3');
INSERT INTO `TaskStatusMaster1` (`id`,`tasktype`,`name`) VALUES 
 (21,'4','4'),
 (21,'5','12'),
 (21,'6','19'),
 (22,'1','21'),
 (22,'2','3'),
 (22,'3','3'),
 (22,'4','4'),
 (22,'5','12'),
 (22,'6','12'),
 (24,'1','12'),
 (24,'2','5'),
 (24,'3','2'),
 (24,'4','4'),
 (24,'5','12'),
 (24,'6','Select'),
 (25,'1','8'),
 (25,'2','3'),
 (25,'3','1'),
 (25,'4','4'),
 (25,'5','7'),
 (25,'6','12'),
 (23,'1','10'),
 (23,'2','3'),
 (23,'3','3'),
 (23,'4','4'),
 (23,'5','12'),
 (23,'6','17'),
 (26,'1','8'),
 (26,'2','8'),
 (26,'3','2'),
 (26,'4','4'),
 (26,'5','26'),
 (26,'6','9'),
 (27,'1','10'),
 (27,'2','3'),
 (27,'3','2'),
 (27,'4','4'),
 (27,'5','12'),
 (27,'6','14'),
 (28,'1','26'),
 (28,'2','5'),
 (28,'3','3'),
 (28,'4','4'),
 (28,'5','5'),
 (28,'6','5'),
 (29,'1','26'),
 (29,'2','6'),
 (29,'3','3'),
 (29,'4','4'),
 (29,'5','6'),
 (29,'6','6'),
 (30,'1','16'),
 (30,'2','6'),
 (30,'3','1'),
 (30,'4','4'),
 (30,'5','26'),
 (30,'6','13'),
 (31,'1','8'),
 (31,'2','5'),
 (31,'3','1'),
 (31,'4','4'),
 (31,'5','8');
INSERT INTO `TaskStatusMaster1` (`id`,`tasktype`,`name`) VALUES 
 (31,'6','32'),
 (32,'1','30'),
 (32,'2','6'),
 (32,'3','2'),
 (32,'4','4'),
 (32,'5','26'),
 (32,'6','32'),
 (33,'1','21'),
 (33,'2','5'),
 (33,'3','1'),
 (33,'4','3'),
 (33,'5','26'),
 (33,'6','9'),
 (34,'1','8'),
 (34,'2','6'),
 (34,'3','1'),
 (34,'4','4'),
 (34,'5','8'),
 (34,'6','32'),
 (35,'1','26'),
 (35,'2','6'),
 (35,'3','2'),
 (35,'4','4'),
 (35,'5','26'),
 (35,'6','12'),
 (36,'1','26'),
 (36,'2','5'),
 (36,'3','3'),
 (36,'4','4'),
 (36,'5','5'),
 (36,'6','5'),
 (37,'1','26'),
 (37,'2','5'),
 (37,'3','2'),
 (37,'4','4'),
 (37,'5','26'),
 (37,'6','12'),
 (38,'1','26'),
 (38,'2','5'),
 (38,'3','3'),
 (38,'4','4'),
 (38,'5','3'),
 (38,'6','5'),
 (39,'1','25'),
 (39,'2','5'),
 (39,'3','1'),
 (39,'4','4'),
 (39,'5','26'),
 (39,'6','17'),
 (40,'1','26'),
 (40,'2','5'),
 (40,'3','2'),
 (40,'4','4'),
 (40,'5','26'),
 (40,'6','2'),
 (41,'1','16'),
 (41,'2','5'),
 (41,'3','3'),
 (41,'4','4'),
 (41,'5','26'),
 (41,'6','14'),
 (42,'1','8');
INSERT INTO `TaskStatusMaster1` (`id`,`tasktype`,`name`) VALUES 
 (42,'2','5'),
 (42,'3','2'),
 (42,'4','4'),
 (42,'5','8'),
 (42,'6','9'),
 (43,'1','15'),
 (43,'2','5'),
 (43,'3','3'),
 (43,'4','4'),
 (43,'5','26'),
 (43,'6','32'),
 (44,'1','8'),
 (44,'2','5'),
 (44,'3','1'),
 (44,'4','4'),
 (44,'5','8'),
 (44,'6','4'),
 (46,'1','33'),
 (46,'2','5'),
 (46,'3','1'),
 (46,'4','4'),
 (46,'5','26'),
 (46,'6','14'),
 (47,'1','34'),
 (47,'2','5'),
 (47,'3','2'),
 (47,'4','4'),
 (47,'5','26'),
 (47,'6','17'),
 (45,'1','25'),
 (45,'2','5'),
 (45,'3','3'),
 (45,'4','4'),
 (45,'5','26'),
 (45,'6','17');
/*!40000 ALTER TABLE `TaskStatusMaster1` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TeamMaster`
--

DROP TABLE IF EXISTS `TeamMaster`;
CREATE TABLE `TeamMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TeamMaster`
--

/*!40000 ALTER TABLE `TeamMaster` DISABLE KEYS */;
INSERT INTO `TeamMaster` (`id`,`name`,`active`) VALUES 
 (1,'SMT BELGAUM',1),
 (2,'BELGAUM REPORTING',1);
/*!40000 ALTER TABLE `TeamMaster` ENABLE KEYS */;


--
-- Table structure for table `NewsMedia`.`TypeMaster`
--

DROP TABLE IF EXISTS `TypeMaster`;
CREATE TABLE `TypeMaster` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `typename` varchar(100) NOT NULL DEFAULT '',
  `active` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NewsMedia`.`TypeMaster`
--

/*!40000 ALTER TABLE `TypeMaster` DISABLE KEYS */;
INSERT INTO `TypeMaster` (`id`,`typename`,`active`) VALUES 
 (1,'Script',1),
 (2,'Voice',1),
 (3,'Editing',1),
 (4,'Upload',1),
 (5,'Typing',1),
 (6,'Video',1);
/*!40000 ALTER TABLE `TypeMaster` ENABLE KEYS */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
