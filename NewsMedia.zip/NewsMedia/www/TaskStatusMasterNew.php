<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>

<?

if($_POST['action'] == "Add")
{
	$id = $_POST['id'];
	$sname = $_POST['sname'];
	$sdate = $_POST['sdate'];
	$source = $_POST['source'];
	$team = $_POST['team'];
	$pdate = $_POST['pdate'];
	$newstype = $_POST['newstype'];
	$vtime = $_POST['vtime'];
	$sector = $_POST['sector'];
	$priority = $_POST['priority'];
	$remark = $_POST['remark'];
	$status = $_POST['status'];


	$maxidno1="select max(id) from TaskStatusMasterNew";
							
		$rs1=exequery($maxidno1);
		$out1=fetch($rs1);
		if($out1[0]!=null)
		$idmax1=$out1[0]+1;	
		else
		{
			$idmax1 =1;
		}
		if($idmax1 != $id)
		{
			echo "Please use Given Id";
			die();
		}
		else
		{
				$qryin="insert into TaskStatusMasterNew (id, name, sdate, source, team, pdate, newstype, videotime, sector, priority, remark, status) values('".mysql_real_escape_string($id)."','".strtoUpper(mysql_real_escape_string($sname))."','".DMYtoYMD($sdate)."','".mysql_real_escape_string($source)."','".mysql_real_escape_string($team)."','".DMYtoYMD($pdate)."','".mysql_real_escape_string($newstype)."','".mysql_real_escape_string($vtime)."','".mysql_real_escape_string($sector)."','".mysql_real_escape_string($priority)."','".mysql_real_escape_string($remark)."','".mysql_real_escape_string($status)."')";
				//echo $qryin."<br>";
				exequery($qryin);
			
			
				$data = $_POST['tempdata'];
				$maindata = explode(':',$data);
				foreach($maindata as $datacourse) 
				{
					$maindata1 = explode('#',$datacourse);
					if ($maindata1[0]!="" && $maindata1[0]!="undefined")
					{
					$qrycourse="insert into TaskStatusMasterNew1(id, tasktype, name) values ('".$_POST['id']."','".$maindata1[0]."','".$maindata1[1]."')";
					exequery($qrycourse);
					//echo $qrycourse;
					}
				}
			
			echo "Added successfully!!!!!!! ";
		}

	die();	
}






if($_POST['action'] == "Search" ) 
{
	
	
	$qry = "select * from TaskStatusMasterNew where id='".$_POST['id']."'";
	//echo $qry;
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else
	{
		$data='';
		$qry1 = "select * from TaskStatusMasterNew1 where id='".$row[0]."'";
	//	echo $qry1;
	    $res1 = exequery($qry1);
		while($row1=fetch($res1))
		{
			$data=$data."&&".$row1[1].":".$row1[2];
		}
		echo  $row[0]."#".$row[1]."#".YMDtoDMY($row[2])."#".$row[3]."#".$row[4]."#".YMDtoDMY($row[5])."#".$row[6]."#".$row[7]."#".$row[8]."#".$row[9]."#".$row[10]."#".$row[11]."#".$data."#";
		
		
		die();
	}
		die();
}


if($_POST['action'] == "Update")
{
	$qry = "UPDATE TaskStatusMasterNew SET name='".mysql_real_escape_string($_POST['sname'])."',sdate='".DMYtoYMD($_POST['sdate'])."',source='".mysql_real_escape_string($_POST['source'])."',team='".mysql_real_escape_string($_POST['team'])."' ,pdate='".DMYtoYMD($_POST['pdate'])."',newstype='".mysql_real_escape_string($_POST['newstype'])."',videotime='".mysql_real_escape_string($_POST['vtime'])."',sector='".mysql_real_escape_string($_POST['sector'])."',priority='".mysql_real_escape_string($_POST['priority'])."',remark='".mysql_real_escape_string($_POST['remark'])."',status='".mysql_real_escape_string($_POST['status'])."' where id='".mysql_real_escape_string($_POST['id'])."'";
	$resq = exequery($qry);
	
	
		$qrycoursedelete="delete from TaskStatusMasterNew1 where id='".$_POST['id']."'";
		exequery($qrycoursedelete);
		
				$data = $_POST['tempdata'];
				$maindata = explode(':',$data);
				foreach($maindata as $datacourse) 
				{
					$maindata1 = explode('#',$datacourse);
					if ($maindata1[0]!="" && $maindata1[0]!="undefined")
					{
						$qrycourse="insert into TaskStatusMasterNew1(id, tasktype, name) values ('".$_POST['id']."','".$maindata1[0]."','".$maindata1[1]."')";
						exequery($qrycourse);
						//echo $qrycourse;
					}
				}
				
	echo "Update successfully!!!!!!! ";
	die();
}


if($_POST['action'] == "Delete")
{
	
	$qrycoursedelete="delete from TaskStatusMasterNew1 where id='".$_POST['id']."'";
	exequery($qrycoursedelete);
		
	$qry = "select id from TaskStatusMasterNew where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		
		
		$qry1 = "delete from TaskStatusMasterNew where id='".$_POST['id']."'";
		$res = exequery($qry1);
		
		$qrycoursedelete="delete from TaskStatusMasterNew1 where id='".$_POST['id']."'";
		exequery($qrycoursedelete);
		
		echo "successfully";
		die();
	}
}

if($_POST['action'] == "loadgid1")
{
?>
	<table class="table">
		<span style='float:right'><input class='btn' type='button' value='Back' name='Action' onclick='window.location.reload();'></span>
		<tr><th>Id</th><th>Story Name</th><th>Date</th><th>Source Name</th><th>Team</th><th>Publish Date</th><th>News Type</th><th>Video Time</th><th>Sector</th><th>Priority</th><th>Remark</th><th>Status</th></tr>
		<tbody>
		<?
			$qry = "select * from TaskStatusMasterNew order by id";
			$res = exequery($qry);
			while($rows = fetch($res))
			{
				
				$qrynews="SELECT * FROM NewsMaster where id=".$rows[6]."";
				$resnews=exequery($qrynews);
				$rownews=fetch($resnews);

				$qrysector="SELECT * FROM SectorMaster where id=".$rows[8]."";
				$ressector=exequery($qrysector);
				$rowsector=fetch($ressector);

				$qryp="SELECT * FROM PriorityMaster where id=".$rows[9]."";
				$resp=exequery($qryp);
				$rowp=fetch($resp);

				$qrys1="SELECT * FROM StatusTaskMaster where id=".$rows[11]."";
				$ress1=exequery($qrys1);
				$rows1=fetch($ress1);
				
				$qrysource="SELECT * FROM SourceMaster where id=".$rows[3]."";
				$ressource=exequery($qrysource);
				$rowsource=fetch($ressource);
				
				$qrysteam="SELECT * FROM TeamMaster where id=".$rows[4]."";
				$resteam=exequery($qrysteam);
				$rowteam=fetch($resteam);
		?>		
			<tr>
				<td><a onclick="tableview(<? echo $rows[0]; ?>);" href="#"><? echo $rows[0]; ?></a></td>
				<td><? echo $rows[1]; ?></td>
				<td><? echo YMDtoDMY($rows[2]); ?></td>
				<td><? echo $rowsource[1]; ?></td>
				<td><? echo $rowteam[1]; ?></td>
				<td><? echo YMDtoDMY($rows[5]); ?></td>
				<td><? echo $rownews[1]; ?></td>
				<td><? echo $rows[7]; ?></td>
				<td><? echo $rowsector[1]; ?></td>
				<td><? echo $rowp[1]; ?></td>
				<td><? echo $rows[10]; ?></td>
				<td><? echo $rows1[1]; ?></td>
				
			
			</tr>
		
		<?
			}
		
		?>
		</tbody>
	</table>
	
<?	
die();
}
?>

<? include('headerorg.php'); ?>
<!------------------ start of datepicker scripts --------------------------------->
<link href="css/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
$( "#sdate" ).datepicker();	
});

$(function() {
$( "#pdate" ).datepicker();	
});

</script>
<!------------------ End of datepicker scripts --------------------------------->

<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;Task Master</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row" >

			<div class="col-sm-12">
			
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Sl.No</label>
				<div class="col-sm-1">
				<?
				
					$qry="select max(id) from TaskStatusMasterNew";
					//echo $qry;
					$result=exequery($qry);
					$rowidno=fetch($result);
					if($rowidno!=null)
					$idno=$rowidno[0]+1;
				
				?>
				<input type="text" class="form-control" id="id" value="<?echo (($search == 1)? :$idno)?>">
				</div>
				<button class="btn" type="button" id='LookUpbutton' name='LookUpbutton' value='LookUp' onclick='LookUp();'>Lookup</button>
				</div><br>
				
			<div class="form-group">
					<label class='control-label col-sm-2'>Story Name</label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="sname"  name="sname" >
				</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Assign Date</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="sdate" name="sdate" placeholder="" >
				</div>
				</div><br><br>
				
			
				<div class="form-group">
					<label class='control-label col-sm-2'>Story By</label>
					<div class="col-sm-4">
					<select class="form-control" id="source" name="source" >
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from SourceMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
			
				
				<?
				    $i=0;
					$selqry = "select * from TypeMaster where active='1'";
					//echo $selqry;
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
				?>
						
					<div class="form-group">
					<label class='control-label col-sm-2'><? echo $selrow[1]?></label>
					<div class="col-sm-4">
					<select class="form-control" id="tasktype<?echo $i;?>" name="tasktype<?echo $i;?>">
					
					<?		
							echo "<option value='Select'>Select</option>";
							$selqry1 = "select * from TaskAssignMaster T, TaskAssignMaster1 T1, TypeMaster M where T.id=T1.id and T1.typename=M.id and M.id='".$selrow[0]."'";
							$selres1 = exequery($selqry1);
							while($selrow1 = fetch($selres1))
							{
								echo "<option value='".$selrow1[0]."'>".$selrow1[1]."</option>";
							}
					?>
					</select>
					
					</div>
					</div><br><br>
					<input type="hidden" class="form-control" id="typeid<?echo $i;?>" name="typeid<?echo $i;?>" value="<?echo $selrow[0]?>" >
				<?
				
				$i++;
					}
					
				?>
				<input type="hidden" class="form-control" id="maincnt" name="maincnt" value="<?echo $i?>" >
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Team</label>
					<div class="col-sm-4">
					<select class="form-control" id="team" name="team" >
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from TeamMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Publish Date</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="pdate" name="pdate" placeholder="" >
				</div>
				</div><br><br>
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>News Type </label>
					<div class="col-sm-4">
					<select class="form-control" id="newstype" name="newstype" >
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from NewsMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Video Time</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="vtime" name="vtime" placeholder="hh:mm:ss">
				</div>
				</div><br><br>
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Sector</label>
					<div class="col-sm-4">
					<select class="form-control" id="sector" name="sector">
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from SectorMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Priority</label>
					<div class="col-sm-4">
					<select class="form-control" id="priority" name="priority" >
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from PriorityMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Remark</label>
				<div class="col-sm-4">
				<textarea class="form-control" rows="3" id="remark" name="remark"></textarea>
				</div>
				</div><br><br><br><br><br>
				
			
					<div class="form-group">
					<label class='control-label col-sm-2'>Status </label>
					<div class="col-sm-4">
					<select class="form-control" id="status"  name="status">
					<?
					echo "<option value='Select'>Select</option>";
					$selqry = "select * from StatusTaskMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
			</div>
      
			<div class="col-sm-2"></div>
			
			<div class="col-sm-10"><br><br>
				&nbsp;&nbsp;&nbsp;<button type="button" class="btn" type="button" id='AddorSearch' name='AddorSearch' value='Add' onclick='AddorUpdate();'>Add</button>
				<button type="button" class="btn" id='DeleteorSearch' name='DeleteorSearch' value='Search' onclick='DeleteSearch();'>Search</button>
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'TaskStatusMasterNew.php'">Cancel</button>
			
			</div>

	  </div>
	  
</div>

</div>
<div id='loadgid'></div>	
</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>


<!------------------- Mobile menu Scripts  ------------------>
</body>



<script type='text/javascript'>


function AddorUpdate()
{
	
	
	var id = $('#id').val();
	var sname = $('#sname').val();
	var sdate = $('#sdate').val();
	var source = $('#source').val();
	var team = $('#team').val();
	var pdate = $('#pdate').val();
	var newstype = $('#newstype').val();
	var vtime = $('#vtime').val();
	var sector = $('#sector').val();
	var priority = $('#priority').val();
	var remark = $('#remark').val();
	var status = $('#status').val();
	
	
	maincnt = $('#maincnt').val();
	tempdata='';
	for(i=0;i<=maincnt;i++)
	{
		temp=$('#tasktype'+i).val();
		temp1=$('#typeid'+i).val();
		tempdata=tempdata+":"+temp1+"#"+temp;
		
	}
	//alert (tempdata);
	//die();

	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	
	if(sname == ""){
		alert("Please Enter Story Name");
		return false;
	}
	
	if(sdate == ""){
		alert("Please Enter Assign Date");
		return false;
	}
	
	if(source == "Select"){
		alert("Please Select Source");
		return false;
	}
	
	if(team == "Select"){
		alert("Please Select Team");
		return false;
	}
	
	/*if(pdate == ""){
		alert("Please Enter Publish Date");
		return false;
	}*/
	
	if(newstype == "Select"){
		alert("Please Select News Type");
		return false;
	}
	
	if(sector == "Select"){
		alert("Please Select Sector");
		return false;
	}
	
	if(priority == "Select"){
		alert("Please Select Priority");
		return false;
	}
	
	
	if(status == "Select"){
		alert("Please Select Status");
		return false;
	}
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"TaskStatusMasterNew.php",
				data:"action="+actiontype+"&id="+id+"&sname="+sname+"&sdate="+sdate+"&source="+source+"&team="+team+"&pdate="+pdate+"&newstype="+newstype+"&vtime="+vtime+"&sector="+sector+"&priority="+priority+"&remark="+remark+"&status="+status+"&tempdata="+tempdata,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

function DeleteSearch()
{
	
	$("#newstype option:selected").text();
	$("#sector option:selected").text();
	$("#priority option:selected").text();
	$("#status option:selected").text();
	$("#team option:selected").text();
	

	var id = $('#id').val();
	if(id == ""){
		alert("Please Enter id");
		return false;
	}
	
	var actiontype = $('#DeleteorSearch').val();
	$.ajax({
				url:"TaskStatusMasterNew.php",
				data:"action="+actiontype+"&id="+id,
				type:"post",
				success:function(output)
				{
				//alert(output);
					output1 = $.trim(output);
					if(output1 == "Notfound")
					{
						alert("Record not found");
						return false;
					}
					
					else if(output1 == "successfully")
					{
						alert("Record Deleted ...!!");
						window.location.reload(true);
						return false;
					}
					else{
						$("#id").prop("readonly", true);
						var store=output1.split('#');	
						$('#id').val(store[0]);
						$('#sname').val(store[1]);
						$('#sdate').val(store[2]);
						$('#source').val(store[3]);
						$('#team').val(store[4]);
						$('#pdate').val(store[5]);
						$('#newstype').val(store[6]);
						$('#vtime').val(store[7]);
						$('#sector').val(store[8]);
						$('#priority').val(store[9]);
						$('#remark').val(store[10]);
						$('#status').val(store[11]);
						
						maincnt =$('#maincnt').val();
					  
						//alert(store[12]);
								  for(j=0;j<=maincnt;j++)
									{
										//alert(j);
										  datatemp = store[12].split('&&');
										for(i=0;i<=datatemp.length-1;i++)
								{
									 datatempmain = datatemp[i].split(':');
									//alert(datatempmain[1]);
								// alert ("type id"+$('#typeid'+j).val());
									 
										if(datatempmain[0]==$('#typeid'+j).val())
										{
										//	alert(datatempmain[2]);
											//$("#tasktype"+j).prop('checked',true);
									//$('#tasktype'+j+' :selected').val();
									$('#tasktype'+j).val(datatempmain[1]);
									//$('#tasktype'+j+' option[value=' + datatempmain[1] + ']').attr('selected', true);
										}
										
										
									}
								}
								
						
						$('#AddorSearch').val('Update');
						$('#AddorSearch').html('Update');
						$('#DeleteorSearch').val('Delete');
						$('#DeleteorSearch').html('Delete');
					
					}
					
				}
	});
	
}

function LookUp()
{
	 $("#loadgid").show();
	 $.ajax({
		url:"TaskStatusMasterNew.php",
		data:"action=loadgid1",
		type:"POST",
		success:function(output)
		{
			//alert(output);
			$('#loadgid').html(output);
			$("#mainform").hide();
			return false;
		}
	  });	
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteorSearch').val('Search');
		DeleteSearch();
}

function GetGender()
{
	var fname = $('#fname').val();
	
	if(fname=="Individual")
	{
		$('#details').show();
	}
	else
	{
		$('#details').hide();
	}
}

</script>
</html>

<?
if($_GET['action'] == "GETSearch")	
{
	?>
	<script> 
	//alert('cmg');
	$('#id').val(<? echo $_GET['id']?>) ;
	$('#DeleteorSearch').val('Search');
		DeleteSearch();
		//alert($('#id').val());
	</script>
	<?
	
}
?>