<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>
<? include('headerorg.php'); ?>

<?

if($_POST['action'] == "Generate")
{
	?>
		<script>
		$(document).ready(function() {
		$('#example').DataTable();
		} );
		</script>

	<?	

	if($_POST['fdate']=="")
	{
	?>
		<script>
		alert('Please Enter From Date');
		window.location.href = 'TaskStatusReport.php';
		</script>	
	<?
	}
	if($_POST['tdate']=="")
	{
	?>
		<script>
		alert('Please Enter To Date');
		window.location.href = 'TaskStatusReport.php';
		</script>	
	<?
	}
	$fdate=$_POST['fdate'];
	$tdate=$_POST['tdate'];
	
	
	
	echo"
	<div class='panel panel-default' style='width:120%;margin-left:1%;' id='generatediv' >
	<div class='panel-heading'>
	<a href='TaskStatusReport.php'><input class='btn' style='font-weight:bold;float:left;margin-top:4%' type='submit' name='Action' id='Action' value='Back'></a>
	<center><h3><a href='#' style='color:#cc470d;font-size:20px;text-align:center;margin-top:5%;height:5px;'>&nbsp;&nbsp;Task Status Report From $fdate To $tdate</a></h3></center>";
	
				echo '<form action="TaskStatusReportExcel.php" method="POST">';
				echo '<input type="hidden" name="fdate" id="fdate" value="'.$_POST['fdate'].'">';
				echo '<input type="hidden" name="tdate" id="tdate" value="'.$_POST['tdate'].'">';
				echo '<input type="hidden" name="status" id="status" value="'.$_POST['status'].'">';
				
				?>
				<input class="btn " style='font-weight:bold;float:right;margin-top:-4%' type='submit' name='Action' id='Action' value='Generate as Excel'>
				
	<? echo '</form></div>';
	
	echo"<div class='panel-body'>
	
	<table id='example' class='display' width='100%' >
	
	<tr style='background-color:#fcddcf;'><th>Sl.No</th><th>Story Name</th><th>Date</th><th>Source Name</th><th>Script</th><th>Voice</th><th>Video</th><th>Editing</th><th>Upload</th><th>Typing</th><th>Team</th><th>Publish Date</th><th>News Type</th><th>Video Time</th><th>Sector</th><th>Priority</th><th style='width:5px;'>Remark</th><th>Status</th></tr>";
		
	$qry="SELECT * FROM TaskStatusMaster where sdate>='".DMYtoYMD($fdate)."' and sdate<='".DMYtoYMD($tdate)."' ";
	if($_POST['status']!='ALL')
	$qry.= "and status='".$_POST['status']."'";
	$qry.= "order by id";
	//echo $qry;
	$res=exequery($qry);
	while($row=fetch($res))
	{
	    $qrynews="SELECT * FROM NewsMaster where id=".$row[6]."";
		$resnews=exequery($qrynews);
		$rownews=fetch($resnews);
		
		$qrysector="SELECT * FROM SectorMaster where id=".$row[8]."";
		$ressector=exequery($qrysector);
		$rowsector=fetch($ressector);
		
		$qryp="SELECT * FROM PriorityMaster where id=".$row[9]."";
		$resp=exequery($qryp);
		$rowp=fetch($resp);
		
		$qrys="SELECT * FROM StatusTaskMaster where id=".$row[11]."";
		$ress=exequery($qrys);
		$rows=fetch($ress);
		
		
		$qrysource="SELECT * FROM SourceMaster where id=".$row[3]."";
		$ressource=exequery($qrysource);
		$rowsource=fetch($ressource);

		$qrysteam="SELECT * FROM TeamMaster where id=".$row[4]."";
		$resteam=exequery($qrysteam);
		$rowteam=fetch($resteam);
				
		if($rows[1]=="ASSIGNED")
		{
			$textcolor='Blue';
		}
		
		if($rows[1]=="IN PROCESS")
		{
			$textcolor='#00b3b3';
		}
		
		if($rows[1]=="PENDING")
		{
			$textcolor='Red';
		}
		if($rows[1]=="COMPLETED")
		{
			$textcolor='Green';
		}
		
		echo"<tr>
		<td><a href='UpdateTaskStatusReport.php?id=$row[0]&action=search' target='_blank' >".$row[0]."</a></td>
		<td>$row[1]</td>
		<td>".YMDtoDMY($row[2])."</td>
		<td>$rowsource[1]</td>";
		
		$qry1="SELECT * FROM TypeMaster ";
		$res1=exequery($qry1);
		while($row1=fetch($res1))
		{
			$qry2="SELECT * FROM TaskStatusMaster1 where tasktype='".$row1[0]."' and id='".$row[0]."'";
			$res2=exequery($qry2);
		    while($row2=fetch($res2))
		    {
			   $qry3="SELECT * FROM TaskAssignMaster where id='".$row2[2]."'";
			   $res3=exequery($qry3);
		       $row3=fetch($res3);
		
		    }
			
			echo"<td>$row3[1]</td>";
		}
		
		
		echo"<td>$rowteam[1]</td>
		<td>".YMDtoDMY($row[5])."</td>
		<td>$rownews[1]</td>
		<td>$row[7]</td>
		<td>$rowsector[1]</td>
		<td>$rowp[1]</td>
		<td>$row[10]</td>
		<td style='color:$textcolor'><b>$rows[1]</b></td>
		</tr>";
	}
	echo"</table></div></div></div>";
	die();
	
}
?>


<!------------------ start of datepicker scripts --------------------------------->
<link href="css/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
$( "#fdate" ).datepicker();	
});

$(function() {
$( "#tdate" ).datepicker();	
});

</script>
<!------------------ End of datepicker scripts --------------------------------->

<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;Task Status Report</a></h3></center></div>
<div class="panel-body">
	  <form method="POST" action="TaskStatusReport.php">
	      <div class="row">
            <div class="col-sm-12">
			  <div class="form-group">
				<label class='control-label col-sm-2'>From Date</label>
					<div class="col-sm-2">
					<input type="text" class="form-control" id="fdate" name="fdate" placeholder="" >
					</div>
			   </div><br><br>
				
			
				<div class="form-group">
					<label class='control-label col-sm-2'>To Date</label>
					<div class="col-sm-2">
					<input type="text" class="form-control" id="tdate" name="tdate" placeholder="" >
					</div>
				</div><br><br>
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Status </label>
					<div class="col-sm-3">
						<select class="form-control" id="status"  name="status">
							<?
							echo "<option value='ALL'>ALL</option>";
							$selqry = "select * from StatusTaskMaster where active='1'";
							$selres = exequery($selqry);
							while($selrow = fetch($selres)){
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
							}
							?>
						</select>
					</div>
				</div><br><br>
			</div>
      <div class="col-sm-2"></div>
	  <div class="col-sm-10"><br><br>
		&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Generate" class='btn' >
	  </div>

	  </div>
	  </form>
</div>

</div>
	
</div>
</div>
</div>
</div>

</body>




</html>