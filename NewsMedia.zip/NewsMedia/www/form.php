<? include('header.php'); ?>


<div class="well" style='border-top: Solid 4px #00BD9C;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:20%;">
<div class="panel-heading"><center><h3><a href="#" style='color:#00BD9C;font-size:24px;'>Student Master</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row">

			<div class="col-sm-12">
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Name</label>
				<div class="col-sm-4">
				<input type="First Name" class="form-control" id="fname">
				</div>
				</div><br>

				<div class="form-group">
				<label class='control-label col-sm-2'>Select</label>
				<div class="col-sm-4">
					<select class="form-control" id="sel1">
					<option>Option 1</option>
					<option>Option 2</option>
					<option>Option 3</option>
					</select>
				</div>
				</div><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Password</label>
				<div class="col-sm-4">
				<input type="password" class="form-control" id="pwd">
				</div>
				</div><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Checkboxes</label>
				<div class="col-sm-4">
				<label class="checkbox-inline"><input type="checkbox" value="">Option 1</label>
				<label class="checkbox-inline"><input type="checkbox" value="">Option 2</label>
				<label class="checkbox-inline"><input type="checkbox" value="">Option 3</label>
				</div>
				</div><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Radio Buttons</label>
				<div class="col-sm-4">
				<label class="radio-inline"><input type="radio" name="optradio">Option 1</label>
				<label class="radio-inline"><input type="radio" name="optradio">Option 2</label>
				<label class="radio-inline"><input type="radio" name="optradio">Option 3</label> 
				</div>
				</div><br>
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Comment</label>
				<div class="col-sm-4">
				<textarea class="form-control" rows="3" id="comment"></textarea>
				</div>
				</div>
				
			</div>
      
			<div class="col-sm-2"></div>
			<div class="col-sm-10"><br><br>
				<button type="button" class="btn">Add</button>
				<button type="button" class="btn">Search</button>
				<button type="button" class="btn">Cancel</button>
			
			</div>

	  </div>			
</div>

</div>

</div>
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="../dist1/jquery.slicknav.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$('#menu').slicknav();
});
</script>

<!------------------- Mobile menu Scripts  ------------------>
</body>
</html>