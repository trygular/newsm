<? include('header.php'); ?>
<style>
.table-striped>tbody>tr:nth-of-type(odd) {
    background-color: #ccfff6;
}

.table-hover>tbody>tr:hover {
    background-color: #ccfff6;
}

</style>

<div class="well" style='border-top: Solid 4px #00BD9C;margin-top:4%;'>

<div class="panel panel-default" style="width:80%;margin-left:20%;">
<div class="panel-heading"><center><h3><a href="#" style='color:#00BD9C;font-size:24px;'>Table</a></h3></center></div>
<div class="panel-body">
	  
		<div class="row">

			<div class="col-sm-12">
			
				<table class="table table-striped">
					<thead>
					<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Email</th>
					</tr>
					</thead>
					<tbody>
					<tr>
					<td>John</td>
					<td>Doe</td>
					<td>john@example.com</td>
					</tr>
					<tr>
					<td>Mary</td>
					<td>Moe</td>
					<td>mary@example.com</td>
					</tr>
					<tr>
					<td>July</td>
					<td>Dooley</td>
					<td>july@example.com</td>
					</tr>
					
					
					</tbody>
				</table>
			</div>
			
		</div><br><br>
			
		<div class="row">
			
			<div class="panel-heading"><center><h3><a href="#" style='color:#00BD9C;font-size:24px;'>Table Hover</a></h3></center></div>
		
			<div class="col-sm-12">
			
				<table class="table table-hover">
					<thead>
					<tr>
					<th>Firstname</th>
					<th>Lastname</th>
					<th>Email</th>
					</tr>
					</thead>
					<tbody>
					<tr>
					<td>John</td>
					<td>Doe</td>
					<td>john@example.com</td>
					</tr>
					<tr>
					<td>Mary</td>
					<td>Moe</td>
					<td>mary@example.com</td>
					</tr>
					<tr>
					<td>July</td>
					<td>Dooley</td>
					<td>july@example.com</td>
					</tr>
					
					
					</tbody>
				</table>
			
			</div>
		</div>

	  </div>			
</div>

</div>

</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="../dist1/jquery.slicknav.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$('#menu').slicknav();
});
</script>

<!------------------- Mobile menu Scripts  ------------------>
</body>
</html>