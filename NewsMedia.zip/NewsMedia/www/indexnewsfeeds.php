<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

/*
	PHP Name : index4.php
	Created Date : 27-03-2018
	Created By :  Abhinandan Budavi
*/



?>

<? include('headerorg1.php');
  include('footer.php'); 
  $actualLink = (isset($_SERVER['HTTPS']) ? "https" : "http") ."://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
  ?>
  <!DOCTYPE html>
<html>
<head>
<title>Tarun Bharat Daily News</title>
<!--<link rel="icon" type="image/png" href="images/ad.jpg">
<meta name="author" content="Tarun Bharat Daily News" >
<meta content="Tarun Bharat Daily News" name="keywords">
<meta content="Tarun Bharat Daily News" name="description">-->
<meta property="og:title" content="Tarun Bharat Daily News">
<meta property="og:image" content="images/ad.jpg">
<meta property="og:description" content="Tarun Bharat Daily News.">
<meta property="og:url" content="<?echo $actualLink;?>">    
</head>
</html>
 <img src="longads.gif" alt="Adds" class="responsive"  style='margin-top:120px; padding:5%; width:100%;'  > 
  
<div class="panel panel-default" style="width:100%;" id='mainform'>
 <div class="panel-body">
 <br>
 <br>
  <br>

	<!--<table width='100%'>		
	<tr><td colspan='4' > <br> <br><td></tr>-->
	
	 <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4 style='color:#cc470d;font-size:14px; text-align:left' >NEWS</h4>
    </div>
    <ul class="w3-ul w3-hoverable w3-white">
	
	
<?

	$qry = "select * from Newsfeeds order by id desc limit 20";
	$res = exequery($qry);
	//$numrow=mysql_num_rows($res);
	while($row = fetch($res)){
		//$temp=$row[0]%2;


	$qry4 = "select * from Newsfeeds1 where id='".$row[0]."'";
	$res4 = exequery($qry4);
	$row4 = fetch($res4);
	
	//if($temp==1){echo "<tr>";}
	?>
	
	
		<a href='http://newsmedia.tarunbharat.co.in/NewsFeedsView.php?id=<?echo $row4[0];?>'   > 
		<li class="w3-padding-16 w3-hide-medium w3-hide-small" style="padding:10%;" >
        <img src="<?echo $row4[2]; ?>" alt="Image" class="w3-left w3-margin-right" style="width:100%; margin-left:2%; ">
        <span class="w3-large"><?echo "Date:" .$row[1]." ".$row[2]."-".$row[3]?></span><br>
        <span><hr></span>
		</li></a> 
	
	<!--<td  style='text-align:right'>
	<img height='30%' width='60%'src='<?//echo $row4[2]; ?>'/>
	<img src="<?//echo $row4[2]; ?>" alt="Adds" class="responsive"  style='margin-top:60px; height:30% padding:5%; width:100%;'  > 
	</td>
	<td  style='font-size:14px; text-align:left; '><a href='http://newsmedia.tarunbharat.co.in/NewsFeedsView.php?action=Generate&id=<?echo $row[0]?>' target="_blank" ><?echo "Date:" .$row[1]."".$row[2]."-".$row[3].$row[3]?></a></td>-->

	
<? 
		//if($temp==0){echo "<tr><td colspan='4' ><hr></td>";}


} 
?>
<!--<tr><td colspan='4' > <br> <br><td></tr>
	
	
 </table>

 --> 
  </ul>
  </div>
 
 
 </div>
 </div>
 
 <img src="longads.gif" alt="Adds" class="responsive"  style='margin-top:20px; padding:5%; width:100%;'  > 
 <br>
 <br>
  <br>
 <br>