<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('DummyData');

?>

<?
if($_POST['action'] == "Delete")
{
	$qry = "select id from userSignin where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		$qry1 = "delete from userSignin where id='".$_POST['id']."'";
		$res = exequery($qry1);
		
		echo "successfully";
		die();
	}
}
if($_POST['action'] == "loadgid1")
{
?>
	
	
<?	
die();
}
?>

<? include('headerorg.php'); ?>


  <div class="container">
   <br><br><br><br><table class="table table-striped">
    <thead>
        <tr>
            <th>Sl. No</th>
            <th>Full Name</th>
            <th>D.O.B</th>
            <th>Email</th>
            <th>Mobile No</th>
			<th>Username</th>
			<th>Actions</th>
        </tr>
    </thead>
    <tbody>
	<?php
	
	$slno=1;
	$qry = "select * from userSignin";
			$res = exequery($qry);
			while($rows = fetch($res))
			{
	?>
        <tr>
            <input type="hidden" name="id" id="id" value="id">
			 <td><? echo $slno; ?></td>
            <td><? echo $rows[1]; ?></td>
            <td><? echo $rows[2]; ?></td>
            <td><? echo $rows[3]; ?></td>
			<td><? echo $rows[4]; ?></td>
			<td><? echo $rows[5]; ?></td>
			<?php $slno++;?>
            <td>
              <a href="useredit.php?id=<?php echo $rows[0];?>"<i style="color:green;font-size:17px" class="glyphicon glyphicon-pencil"></i></a>
             <button type="button" class="btn"  id='DeleteorSearch' name='DeleteorSearch' value='Search' onclick='DeleteSearch();'>Delete</button>
            </td>
        </tr>
		
		<?
			}
		
		?>
        </tbody>
 </table>
 </div>
	</div>
	<div id='loadgid'></div>	
	</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>


<!------------------- Mobile menu Scripts  ------------------>
</body>



<script type='text/javascript'>

function check()
{

    var pass1 = document.getElementById('mobno');


    var message = document.getElementById('message');

   var goodColor = "#cc470d";
    var badColor = "#cc470d";

    if(mobno.value.length!=10){

       // mobno.style.backgroundColor = badColor;
        message.style.color = badColor;
        message.innerHTML = " Mobile number start with 91"
    }
}
	
	

function AddorUpdate()
{
	var id = $('#id').val();
	var fname = $('#fname').val();
	var fname1 = $('#fname1').val();
	var male = $('#male').val();
	var female = $('#female').val();
	var mobno = $('#mobno').val();
	var email = $('#email').val();
	var address = $('#address').val();
	var occupation = $('#occupation').val();
	var interest1 = $('#interest1').val();
	var interest2 = $('#interest2').val();
	var interest3 = $('#interest3').val();
	var interest4 = $('#interest4').val();
	var suggestion = $('#suggestion').val();
	
	/*var emailRegex = new RegExp(/^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i);
	var valid = emailRegex.test(email);
	if (!valid) {
	alert("Invalid e-mail address");
	return false;
	} else
	return true;*/

	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	
	if(fname == "Select"){
		alert("Please Select Name");
		return false;
	}
	
	if(mobno == ""){
		alert("Please Enter Mobile Number");
		return false;
	}
	
	if(address == ""){
		alert("Please Enter address");
		return false;
	}
	
	if(occupation == "Select"){
		alert("Please Select Occupation");
		return false;
	}
	
	if(($('#male').is(':checked')) == true)
	{
		 gender ="male";
		
	}
	if(($('#female').is(':checked')) == true)
	{
		 gender ="female";
	}
	
	if(($('#interest1').is(':checked')) == true)
	{
		 interest1 ='1';
		
	}
	if(($('#interest2').is(':checked')) == true)
	{
		 interest2 ='1';
	}
	if(($('#interest3').is(':checked')) == true)
	{
		 interest3 ='1';
		
	}
	if(($('#interest4').is(':checked')) == true)
	{
		 interest4 ='1';
	}
	
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"indexorg.php",
				data:"action="+actiontype+"&id="+id+"&fname="+fname+"&fname1="+fname1+"&gender="+gender+"&mobno="+mobno+"&email="+email+"&address="+address+"&occupation="+occupation+"&interest1="+interest1+"&interest2="+interest2+"&interest3="+interest3+"&interest4="+interest4+"&suggestion="+suggestion,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

function DeleteSearch()
{
	var id = $('#id').val();
	if(id == ""){
		alert("Please Enter id");
		return false;
	}
	
	var actiontype = $('#DeleteorSearch').val();
	$.ajax({
				url:"indexorg.php",
				data:"action="+actiontype+"&id="+id,
				type:"post",
				success:function(output)
				{
					alert(actiontype);
					output1 = $.trim(output);
					if(output1 == "Notfound")
					{
						alert("Record not found");
						return false;
					}
					
					else if(output1 == "successfully")
					{
						alert("Record Deleted ...!!");
						window.location.reload(true);
						return false;
					}
					else{
						$("#id").prop("readonly", true);
						var store=output1.split('#');	
						$('#id').val(store[0]);
						$('#fname').val(store[1]);
						$('#fname1').val(store[2]);

						 if(store[3] == "female")
						{
							$('#female' ).attr( "checked",true);
						}
						else
						{
							$('#female' ).attr( "checked",false);
							$('#male').attr('checked', true);	
						}
						
						$('#mobno').val(store[4]);
						$('#address').val(store[5]);
						$('#occupation').val(store[6]);		
						$('#suggestion').val(store[7]);
						$('#email').val(store[8]);
						
						$('#AddorSearch').val('Update');
						$('#AddorSearch').html('Update');
						$('#DeleteorSearch').val('Delete');
						$('#DeleteorSearch').html('Delete');
					
					}
					
				}
	});
	
}

    function deleletconfig(){

    var del=confirm("Are you sure you want to delete this record?");
    if (del==true){
       alert ("record deleted")
    }else{
        alert("Record Not Deleted")
    }
    return del;
    }


function LookUp()
{
	 $("#loadgid").show();
	 $.ajax({
		url:"indexorg.php",
		data:"action=loadgid1",
		type:"POST",
		success:function(output)
		{
			//alert(output);
			$('#loadgid').html(output);
			$("#mainform").hide();
			return false;
		}
	  });	
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteorSearch').val('Search');
		DeleteSearch();
}

function GetGender()
{
	var fname = $('#fname').val();
	
	if(fname=="Individual")
	{
		$('#details').show();
	}
	else
	{
		$('#details').hide();
	}
}

</script>
</html>