<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.footer {
   position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #091929;
   color: white;
   text-align: center;
}
</style>
</head>
<body>
<div class="footer">
		
<?echo '<!-- AddToAny BEGIN -->
<div class="a2a_kit a2a_kit_size_32 a2a_default_style">
<a class="a2a_button_facebook" target="_blank" ></a>
<a class="a2a_button_twitter" target="_blank" ></a>
<a class="a2a_button_whatsapp" target="_blank" ></a>

</div>
<script async src="https://static.addtoany.com/menu/page.js"></script>
<!-- AddToAny END -->';?>
		
</div>

</body>
</html> 