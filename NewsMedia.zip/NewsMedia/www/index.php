<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>

<?

if($_POST['action'] == "Add")
{
	$id = $_POST['id'];
	$fname = $_POST['fname'];
	$fname1 = $_POST['fname1'];
	$gender = $_POST['gender'];
	$mobno = $_POST['mobno'];
	$email = $_POST['email'];
	$address = $_POST['address'];
	$occupation = $_POST['occupation'];
	$interest1 = $_POST['interest1'];
	$interest2 = $_POST['interest2'];
	$interest3 = $_POST['interest3'];
	$interest4 = $_POST['interest4'];
	$suggestion = $_POST['suggestion'];
	
	$email  = $_POST['email'];
	$emailB = filter_var($email, FILTER_SANITIZE_EMAIL);

	if (filter_var($emailB, FILTER_VALIDATE_EMAIL) === false ||
	$emailB != $email
	) {
	echo "Invalid Email ID !";
	exit(0);
	}

	$maxidno1="select max(id) from NewData";
							
		$rs1=exequery($maxidno1);
		$out1=fetch($rs1);
		if($out1[0]!=null)
		$idmax1=$out1[0]+1;	
		else
		{
			$idmax1 =1;
		}
		if($idmax1 != $id)
		{
			echo "Please use Given Id";
			die();
		}
		else
		{
				$qryin="insert into NewData (id, name,subname, gender, mobno, address, occupation, suggestion, email) values('".mysql_real_escape_string($id)."','".mysql_real_escape_string($fname)."','".mysql_real_escape_string($fname1)."','".mysql_real_escape_string($gender)."','".mysql_real_escape_string($mobno)."','".mysql_real_escape_string($address)."','".mysql_real_escape_string($occupation)."','".mysql_real_escape_string($suggestion)."','".mysql_real_escape_string($email)."')";
				//echo $qryin;
				exequery($qryin);
			
			
			if($interest1==1)
			{
				$interest1="Politics";
				$qryinsert="insert into NewData1 (id, interest) values('".mysql_real_escape_string($id)."','".mysql_real_escape_string($interest1)."')";
				exequery($qryinsert);
			}
			
			if($interest2==1)
			{
				$interest2="Sports";
				$qryinsert2="insert into NewData1 (id, interest) values('".mysql_real_escape_string($id)."','".mysql_real_escape_string($interest2)."')";
				exequery($qryinsert2);
			}
			
			if($interest3==1)
			{
				$interest3="Entertainment";
				$qryinsert3="insert into NewData1 (id, interest) values('".mysql_real_escape_string($id)."','".mysql_real_escape_string($interest3)."')";
				exequery($qryinsert3);
			}
			
			if($interest4==1)
			{
				$interest4="Cultural";
				$qryinsert4="insert into NewData1 (id, interest) values('".mysql_real_escape_string($id)."','".mysql_real_escape_string($interest4)."')";
				exequery($qryinsert4);
			}
			
			echo "Added successfully!!!!!!!";
			die();
			
		}

	die();	
}


if($_POST['action'] == "Search")
{
	$qry = "select* from NewData where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		echo  $row[0]."#".$row[1]."#".$row[2]."#".$row[3]."#".$row[4]."#".$row[5]."#".$row[6]."#".$row[7]."#".$row[8];
		die();
		}
		die();
}



if($_POST['action'] == "Update"){
	$qry = "UPDATE NewData SET name='".mysql_real_escape_string($_POST['fname'])."',subname='".mysql_real_escape_string($_POST['fname1'])."',gender='".mysql_real_escape_string($_POST['gender'])."',mobno='".mysql_real_escape_string($_POST['mobno'])."' ,address='".mysql_real_escape_string($_POST['address'])."',occupation='".mysql_real_escape_string($_POST['occupation'])."',suggestion='".mysql_real_escape_string($_POST['suggestion'])."',email='".mysql_real_escape_string($_POST['email'])."' where id='".mysql_real_escape_string($_POST['id'])."'";
	$resq = exequery($qry);
	
	echo "Update successfully!!!!!!! ";
	die();
}


if($_POST['action'] == "Delete")
{
	$qry = "select id from NewData where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		$qry1 = "delete from NewData where id='".$_POST['id']."'";
		$res = exequery($qry1);
		
		echo "successfully";
		die();
	}
}

if($_POST['action'] == "loadgid1")
{
?>
	<table class="table" >
		<span style='float:right'><input class='btn' type='button' value='Back' name='Action' onclick='window.location.reload();'></span>
		<tr><th>Id</th><th>Name</th><th>Sub Name</th><th>Mobile No</th><th>Email Id</th><th>Address</th><th>Occupation</th><th>Interested</th></tr>
		<tbody>
		<?
			$qry = "select * from NewData";
			$res = exequery($qry);
			while($rows = fetch($res))
			{
				
		?>		
			<tr>
				<td><a onclick="tableview(<? echo $rows[0]; ?>);" href="#"><? echo $rows[0]; ?></a></td>
				<td><? echo $rows[1]; ?></td>
				<td><? echo $rows[2]; ?></td>
				<td><? echo $rows[4]; ?></td>
				<td><? echo $rows[8]; ?></td>
				<td><? echo $rows[5]; ?></td>
				<td><? echo $rows[6]; ?></td>
				<td>
				<?
					$qry2="SELECT * FROM NewData1 where id='".$rows[0]."'";
					$res2= exequery($qry2);
					while($rows2= fetch($res2))
					{
						echo $rows2[1]."<br>"; 
					}
				?>
				</td>
			
			</tr>
		
		<?
			}
		
		?>
		</tbody>
	</table>
	
<?	
die();
}
?>

<? include('header.php'); ?>


<div class="well" style='border-top: Solid 6px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;Contact Details</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row" >

			<div class="col-sm-12">
			
				<?
				
					$qry="select max(id) from NewData";
					//echo $qry;
					$result=exequery($qry);
					$rowidno=fetch($result);
					if($rowidno!=null)
					$idno=$rowidno[0]+1;
				
				?>
				<input type="hidden" class="form-control" id="id" value="<?echo (($search == 1)? :$idno)?>">
			
			<!--	<button class="btn" type="button" id='LookUpbutton' name='LookUpbutton' value='LookUp' onclick='LookUp();'>Lookup</button>-->
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Name </label>
				<div class="col-sm-4">
					<select class="form-control" id="fname" name="fname" onchange="GetGender();">
					<?
					echo "<option value='Select'>Select</option>";
						$selqry = "select * from StatusMaster where active='1'";
						$selres = exequery($selqry);
						while($selrow = fetch($selres)){
							echo "<option value='".$selrow[1]."'>".$selrow[1]."</option>";
						}
					?>
					</select>
				</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'></label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="fname1" name="fname1" placeholder="Enter Name" >
				</div>
				</div><br><br>
				
				<div  style='display:none;'  id="details">
					<div class="form-group" >
					<label class='control-label col-sm-2'>Gender</label>
					<div class="col-sm-4">
					<label class="radio-inline"><input type="radio" name="gender" id="male" value="male" checked>Male</label>
					<label class="radio-inline"><input type="radio" name="gender" id="female" value="female" >Female</label>
					</div>
					</div><br><br>
				</div>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Mobile NO.<img src="images/wa.svg" style='width:40px;height:40px;' /></label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="mobno" name="mobno" onkeyup="check(); return false;"><span id="message"></span>
				</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Email Id</label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="email"  name="email" >
				</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Address</label>
				<div class="col-sm-4">
				<textarea class="form-control" rows="3" id="address" name="address"></textarea>
				</div>
				</div><br><br><br><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Occupation </label>
				<div class="col-sm-4">
					<select class="form-control" id="occupation" name="occupation">
					<?
					echo "<option value='Select'>Select</option>";
						$selqry = "select * from OccupationMaster where active='1'";
						$selres = exequery($selqry);
						while($selrow = fetch($selres)){
							echo "<option value='".$selrow[1]."'>".$selrow[1]."</option>";
						}
					?>
					</select>
				</div>
				</div><br><br>
				
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Interested In</label>
				<div class="col-sm-6">
				<label class="checkbox-inline"><input type="checkbox" name="interest1" value="Politics" id="interest1">Politics</label>
				<label class="checkbox-inline"><input type="checkbox" name="interest2" value="Sports" id="interest2">Sports</label>
				<label class="checkbox-inline"><input type="checkbox" name="interest3" value="Entertainment" id="interest3">Entertainment</label>
				<label class="checkbox-inline"><input type="checkbox" name="interest4" value="Cultural" id="interest4">Cultural</label>
				</div>
				</div><br><br>
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Suggestion</label>
				<div class="col-sm-4">
				<textarea class="form-control" rows="3" id="suggestion" name="suggestion"></textarea>
				</div>
				</div><br>
				
				
				
			</div>
      
			<div class="col-sm-2"></div>
			<div class="col-sm-10"><br><br>
				&nbsp;&nbsp;&nbsp;<button type="button" class="btn" type="button" id='AddorSearch' name='AddorSearch' value='Add' onclick='AddorUpdate();'>Add</button>
				<!--<button type="button" class="btn" id='DeleteorSearch' name='DeleteorSearch' value='Search' onclick='DeleteSearch();'>Search</button>-->
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'index.php'">Cancel</button>
			
			</div>

	  </div>
	  
</div>

</div>
<div id='loadgid'></div>	
</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>


<!------------------- Mobile menu Scripts  ------------------>
</body>

<script type='text/javascript'>



function check()
{

	var pass1 = document.getElementById('mobno');
	var message = document.getElementById('message');

	var goodColor = "#cc470d";
	var badColor = "#cc470d";

	if(mobno.value.length!=10){

	// mobno.style.backgroundColor = badColor;
	message.style.color = badColor;
	 message.innerHTML = " Mobile number start with 91"
}}
	
	

function AddorUpdate()
{
	var id = $('#id').val();
	var fname = $('#fname').val();
	var fname1 = $('#fname1').val();
	var male = $('#male').val();
	var female = $('#female').val();
	var mobno = $('#mobno').val();
	var email = $('#email').val();
	var address = $('#address').val();
	var occupation = $('#occupation').val();
	var interest1 = $('#interest1').val();
	var interest2 = $('#interest2').val();
	var interest3 = $('#interest3').val();
	var interest4 = $('#interest4').val();
	var suggestion = $('#suggestion').val();
	
	/*var emailRegex = new RegExp(/^([\w\.\-]+)@([\w\-]+)((\.(\w){2,3})+)$/i);
	var valid = emailRegex.test(email);
	if (!valid) {
	alert("Invalid e-mail address");
	return false;
	} else
	return true;*/

	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	
	if(fname == "Select"){
		alert("Please Select Name");
		return false;
	}
	
	if(mobno == ""){
		alert("Please Enter Mobile Number");
		return false;
	}
	if(email == ""){
		alert("Please Enter Email ID");
		return false;
	}
	
	if(address == ""){
		alert("Please Enter address");
		return false;
	}
	
	if(occupation == "Select"){
		alert("Please Select Occupation");
		return false;
	}
	
	if(($('#male').is(':checked')) == true)
	{
		 gender ="male";	
	}
	if(($('#female').is(':checked')) == true)
	{
		 gender ="female";
	}
	if(($('#interest1').is(':checked')) == true)
	{
		 interest1 ='1';	
	}
	if(($('#interest2').is(':checked')) == true)
	{
		 interest2 ='1';
	}
	if(($('#interest3').is(':checked')) == true)
	{
		 interest3 ='1';
	}
	if(($('#interest4').is(':checked')) == true)
	{
		 interest4 ='1';
	}
	
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"index.php",
				data:"action="+actiontype+"&id="+id+"&fname="+fname+"&fname1="+fname1+"&gender="+gender+"&mobno="+mobno+"&email="+email+"&address="+address+"&occupation="+occupation+"&interest1="+interest1+"&interest2="+interest2+"&interest3="+interest3+"&interest4="+interest4+"&suggestion="+suggestion,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

function DeleteSearch()
{
	var id = $('#id').val();
	if(id == ""){
		alert("Please Enter id");
		return false;
	}
	
	var actiontype = $('#DeleteorSearch').val();
	$.ajax({
				url:"index.php",
				data:"action="+actiontype+"&id="+id,
				type:"post",
				success:function(output)
				{
					//alert(output);
					output1 = $.trim(output);
					if(output1 == "Notfound")
					{
						alert("Record not found");
						return false;
					}
					
					else if(output1 == "successfully")
					{
						alert("Record Deleted ...!!");
						window.location.reload(true);
						return false;
					}
					else{
						$("#id").prop("readonly", true);
						var store=output1.split('#');	
						$('#id').val(store[0]);
						$('#fname').val(store[1]);
						$('#fname1').val(store[2]);

						 if(store[3] == "female")
						{
							$('#female' ).attr( "checked",true);
						
						}
						else
						{
							$('#female' ).attr( "checked",false);
							$('#male').attr('checked', true);	
						}
						
						$('#mobno').val(store[4]);
						$('#address').val(store[5]);
						$('#occupation').val(store[6]);		
						$('#suggestion').val(store[7]);
						$('#email').val(store[8]);
						
						$('#AddorSearch').val('Update');
						$('#AddorSearch').html('Update');
						$('#DeleteorSearch').val('Delete');
						$('#DeleteorSearch').html('Delete');
					
					}
					
				}
	});
	
}

function LookUp()
{
	 $("#loadgid").show();
	 $.ajax({
		url:"index.php",
		data:"action=loadgid1",
		type:"POST",
		success:function(output)
		{
			//alert(output);
			$('#loadgid').html(output);
			$("#mainform").hide();
			return false;
		}
	  });	
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteorSearch').val('Search');
		DeleteSearch();
}

function GetGender()
{
	var fname = $('#fname').val();
	
	if(fname=="Individual")
	{
		$('#details').show();
	}
	else
	{
		$('#details').hide();
	}
}

</script>
</html>