<?php 
	include("/etc/tbdconfig.php");
	mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
	usedb('DummyData');
	$fname=$_POST['fname'];
	$doj=$_POST['doj'];
	$email=$_POST['email'];
	$mobileno=$_POST['mobileno'];
    $username=$_POST['username'];
	$password=$_POST['password'];
	
	
	$success=0;
	$status="Active";
	/*$sql = "INSERT INTO  `userSignin` (`username`, `password`, `email`, `mobileno`) 
	VALUES ('$username','password($password)','$email','$mobileno')";*/
	
	$sql = "INSERT INTO  userSignin (fname, doj, email, mobileno, username, password ) 
	VALUES ('".$_POST['fname']."','".$_POST['doj']."','".$_POST['email']."','".$_POST['mobileno']."','".$_POST['username']."',password('".$_POST['password']."'))";
	
    echo $sql;
	if(mysql_query($sql))
	{
	header('location:login.php');
	$success=1;
	} 
	
?>



