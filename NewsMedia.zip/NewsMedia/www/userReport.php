<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('DummyData');

?>
<? include('headerorg.php'); ?>

<?

if($_POST['action'] == "Generate")
{
	echo"
	<div class='panel panel-default' style='width:120%;margin-left:1%;' id='generatediv' >
	<div class='panel-heading'>
	<a href='userReport.php'><input class='btn' style='font-weight:bold;float:left;margin-top:4%' type='submit' name='Action' id='Action' value='Back'></a>
	<center><h3><a href='#' style='color:#cc470d;font-size:20px;text-align:center;margin-top:5%;height:5px;'>&nbsp;&nbsp;Task Status Report From $fdate To $tdate</a></h3></center>";
	
	echo '<form action="userReport.php" method="POST">';
	echo '<input type="hidden" name="id" id="username" value="'.$_POST['id'].'">';
	?>
	<input class="btn " style='font-weight:bold;float:right;margin-top:-4%' type='submit' name='Action' id='Action' value='Generate as Excel'>
				
	<? echo '</form></div>';
	echo"<div class='panel-body'>
	<table class='table' style='width:100%;' >
	<tr style='background-color:#fcddcf;'><th>Full Name</th><th>D.O.j</th><th>Email </th><th>Mobile No</th><th>Username</th></tr>";
	$qry="SELECT * FROM userSignin";
	if($_POST['id']!='ALL')
	$qry.= " WHERE id='".$_POST['id']."'";	
	
	//$qry.= " order by id";
	
	$res=exequery($qry);
	
	while($rows = fetch($res))
	{
		echo"<tr>
		<td>$rows[1]</td>
		<td>".DMYtoYMD($rows[2])."</td>
		<td>$rows[3]</td>";
		echo"<td>$rows[4]</td>
		<td>$rows[5]</td>
		</tr>";
	}
	

	echo"</table></div></div></div>";
	die();
	
}
?>


<!------------------ start of datepicker scripts --------------------------------->
<link href="css/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
$( "#fdate" ).datepicker();	
});

$(function() {
$( "#tdate" ).datepicker();	
});

</script>
<!------------------ End of datepicker scripts --------------------------------->

<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;User Status Report</a></h3></center></div>
<div class="panel-body">
	  <form method="POST" action="userReport.php">
	      <div class="row">
            <div class="col-sm-12">
			   <div class="form-group">
					<label class='control-label col-sm-2'>Status </label>
					<div class="col-sm-3">
						<select class="form-control" id="id"  name="id">
							<?
							echo "<option value='ALL'>ALL</option>";
							$selqry = "select * from userSignin";
							$selres = exequery($selqry);
							while($selrow = fetch($selres)){
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
							}
							?>
						</select>
					</div>
				</div><br><br>
			</div>
      <div class="col-sm-2"></div>
	  <div class="col-sm-10"><br><br>
		&nbsp;&nbsp;&nbsp;<input type="submit" name="action" value="Generate" class='btn' >
	  </div>
    </div>
	</form>
</div>
</div>
	
</div>
</div>
</div>
</div>

</body>




</html>