<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>

<?

if($_POST['action'] == "Add")
{
	$id = $_POST['id'];
	$status = $_POST['status'];
	
	$maxidno1="select max(id) from StatusTaskMaster";
							
		$rs1=exequery($maxidno1);
		$out1=fetch($rs1);
		if($out1[0]!=null)
		$idmax1=$out1[0]+1;	
		else
		{
			$idmax1 =1;
		}
		if($idmax1 != $id)
		{
			echo "Please use Given Id";
			die();
		}
		else
		{
			$qryin="insert into StatusTaskMaster (id, status, active) values('".mysql_real_escape_string($id)."','".strtoUpper(mysql_real_escape_string($status))."','".mysql_real_escape_string($_POST['active'])."')";
			//echo $qryin;
			exequery($qryin);
			echo "Added successfully!!!!!!!";
			die();
			
		}
	die();	
}


if($_POST['action'] == "Search")
{
	$qry = "select* from StatusTaskMaster where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		echo  $row[0]."#".$row[1]."#".$row[2];
		die();
		}
		die();
}



if($_POST['action'] == "Update"){
	$qry = "UPDATE StatusTaskMaster SET status='".mysql_real_escape_string($_POST['status'])."',active='".mysql_real_escape_string($_POST['active'])."' where id='".mysql_real_escape_string($_POST['id'])."'";
	$resq = exequery($qry);
	
	echo "Update successfully!!!!!!! ";
	die();
}


if($_POST['action'] == "Delete")
{
	$qry = "select id from StatusTaskMaster where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		$qry1 = "delete from StatusTaskMaster where id='".$_POST['id']."'";
		$res = exequery($qry1);
		
		echo "successfully";
		die();
	}
}

if($_POST['action'] == "loadgid1")
{
?>
	<table class="table" >
		<span style='float:right'><input class='btn' type='button' value='Back' name='Action' onclick='window.location.reload();'></span>
		<tr><th>Id</th><th>Status</th><th>Active</th></tr>
		<tbody>
		<?
			$qry = "select * from StatusTaskMaster";
			$res1 = exequery($qry);
			while($rows = fetch($res1))
			{
				
		?>		
			<tr>
				<td><a onclick="tableview(<? echo $rows[0]; ?>);" href="#"><? echo $rows[0]; ?></a></td>
				<td><? echo $rows[1]; ?></td>
				<td><? echo $rows[2]; ?></td>
			
			</tr>
		
		<?
			}
		
		?>
		</tbody>
	</table>
	
<?	
die();
}


?>

<? include('headerorg.php'); ?>


<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;Status Task Master</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row" >

			<div class="col-sm-12">
			
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Id</label>
				<div class="col-sm-1">
				<?
				
					$qry="select max(id) from StatusTaskMaster";
					//echo $qry;
					$result=exequery($qry);
					$rowidno=fetch($result);
					if($rowidno!=null)
					$idno=$rowidno[0]+1;
				
				?>
				<input type="text" class="form-control" id="id" name="id" value="<?echo (($search == 1)? :$idno)?>">
				</div>
				<button class="btn" type="button" id='LookUpbutton' name='LookUpbutton' value='LookUp' onclick='LookUp();'>Lookup</button>
				</div><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Status</label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="status" name="status" >
				</div>
				</div><br>
				
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Active</label>
				<div class="col-sm-6">
				<label class="checkbox-inline"><input type="checkbox" name="active" id="active"></label>
				
				</div>
				</div><br>
				
				
				
			</div>
      
			<div class="col-sm-2"></div>
			<div class="col-sm-10"><br><br>
				<button type="button" class="btn" type="button" id='AddorSearch' name='AddorSearch' value='Add' onclick='AddorUpdate();'>Add</button>
				<button type="button" class="btn" id='DeleteorSearch' name='DeleteorSearch' value='Search' onclick='DeleteSearch();'>Search</button>
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'StatusTaskMaster.php'">Cancel</button>
			
			</div>

	  </div>
	  
</div>

</div>
<div id='loadgid'></div>	
</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


</body>

<script type='text/javascript'>
function AddorUpdate()
{
	var id = $('#id').val();
	var status = $('#status').val();
	
	
	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	if(status == ""){
		alert("Please Enter Status");
		return false;
	}
	
	if($("#active").prop('checked') == true){
		var active = '1';
	}
	else{
		var active = '0';
	}
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"StatusTaskMaster.php",
				data:"action="+actiontype+"&id="+id+"&status="+status+"&active="+active,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

function DeleteSearch()
{
	var id = $('#id').val();
	if(id == "")
	{
		alert("Please Enter id");
		return false;
	}
	
	var actiontype = $('#DeleteorSearch').val();
	$.ajax({
				url:"StatusTaskMaster.php",
				data:"action="+actiontype+"&id="+id,
				type:"post",
				success:function(output)
				{
					//alert(output);
					output1 = $.trim(output);
					if(output1 == "Notfound")
					{
						alert("Record not found");
						return false;
					}
					
					else if(output1 == "successfully")
					{
						alert("Record Deleted ...!!");
						window.location.reload(true);
						return false;
					}
					else{
						$("#id").prop("readonly", true);
						var store=output1.split('#');	
						$('#id').val(store[0]);
						$('#status').val(store[1]);

						if(store[2] == 1){
						//$('#activ').prop('checked', true);
						$('#active').attr('checked', true);
						$("#uniform-activ").removeClass("checker");
						}
						else{
						$('#active').attr('checked', false);
						}
						
						
						$('#AddorSearch').val('Update');
						$('#AddorSearch').html('Update');
						$('#DeleteorSearch').val('Delete');
						$('#DeleteorSearch').html('Delete');
					
					}
					
				}
	});
	
}

function LookUp()
{
	 $("#loadgid").show();
	 $.ajax({
		url:"StatusTaskMaster.php",
		data:"action=loadgid1",
		type:"POST",
		success:function(output)
		{
			//alert(output);
			$('#loadgid').html(output);
			$("#mainform").hide();
			return false;
		}
	  });	
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteorSearch').val('Search');
		DeleteSearch();
}
</script>
</html>