<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>

<?

if($_POST['action'] == "Add")
{
	$id = $_POST['id'];
	$fname = $_POST['fname'];
	
	$maxidno1="select max(id) from TaskAssignMaster";
							
		$rs1=exequery($maxidno1);
		$out1=fetch($rs1);
		if($out1[0]!=null)
		$idmax1=$out1[0]+1;	
		else
		{
			$idmax1 =1;
		}
		if($idmax1 != $id)
		{
			echo "Please use Given Id";
			die();
		}
		else
		{
			$qryin="insert into TaskAssignMaster (id, name) values('".mysql_real_escape_string($id)."','".strtoUpper(mysql_real_escape_string($fname))."')";
			//echo $qryin;
			exequery($qryin);

			$data = $_POST['tempdata'];
			$maindata = explode(':',$data);
			foreach($maindata as $datacourse) 
			{
				//echo $datacourse;
				if ($datacourse[0]!="")
				{
				$qrycourse="insert into TaskAssignMaster1(id, typename) values ('".$_POST['id']."','".$datacourse[0]."')";
				exequery($qrycourse);
				//echo $qrycourse;
				}
			}
			
		
			echo "Added successfully!!!!!!!";
			die();
			
		}
	die();	
}


if($_POST['action'] == "Search")
{
	$qry = "select* from TaskAssignMaster where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else
	{
	
		$data='';
		$qry1 = "select * from TaskAssignMaster1 where id='".$row[0]."'";
	    $res1 = exequery($qry1);
		while($row1=fetch($res1))
		{
			$data=$data.":".$row1[1];
		}
		echo  $row[0]."#".$row[1]."#".$data."#";
		
		$qry1 = "select * from TypeMaster ";
	    $res1 = exequery($qry1);
		while($row1=fetch($res1))
		{
			echo $row1[0]."&".$row1[1];
		}
		
		
		die();
	}
	
	
		
		
}



if($_POST['action'] == "Update"){
	$qry = "UPDATE TaskAssignMaster SET name='".mysql_real_escape_string($_POST['fname'])."' where id='".mysql_real_escape_string($_POST['id'])."'";
	$resq = exequery($qry);
	
		$qrycoursedelete="delete from TaskAssignMaster1 where id='".$_POST['id']."'";
		exequery($qrycoursedelete);
			
		$data = $_POST['tempdata'];
		$maindata = explode(':',$data);
		foreach($maindata as $datacourse) 
		{
			//echo $datacourse;
			if ($datacourse[0]!="")
			{
			$qrycourse="insert into TaskAssignMaster1(id, typename) values ('".$_POST['id']."','".$datacourse[0]."')";
			exequery($qrycourse);
			//echo $qrycourse;
			}
		}
			
	echo "Update successfully!!!!!!! ";
	die();
}


if($_POST['action'] == "Delete")
{
	$qry = "select id from TaskAssignMaster where id='".$_POST['id']."'";
	$res = exequery($qry);
	$nrow = mysql_num_rows($res);
	$row = fetch($res);
	if($nrow != 1)
	{
		echo "Notfound";
		die();
	}
	else{
		$qry1 = "delete from TaskAssignMaster where id='".$_POST['id']."'";
		$res = exequery($qry1);
		
		echo "successfully";
		die();
	}
}

if($_POST['action'] == "loadgid1")
{
?>
	<table class="table" >
		<span style='float:right'><input class='btn' type='button' value='Back' name='Action' onclick='window.location.reload();'></span>
		<tr><th>Id</th><th>Name</th><th>Type</th></tr>
		<tbody>
		<?
			$qry = "select * from TaskAssignMaster";
			$res1 = exequery($qry);
			while($rows = fetch($res1))
			{
				
		?>		
			<tr>
				<td><a onclick="tableview(<? echo $rows[0]; ?>);" href="#"><? echo $rows[0]; ?></a></td>
				<td><? echo $rows[1]; ?></td>
				<td>
				<?
					$qry2="SELECT * FROM TaskAssignMaster1 where id='".$rows[0]."'";
					$res2= exequery($qry2);
					while($rows2= fetch($res2))
					{
						$qry3="SELECT * FROM TypeMaster where id='".$rows2[1]."'";
						$res3= exequery($qry3);
						$rows3= fetch($res3);
						
						echo $rows3[1]."<br>"; 
					}
				?>
			</td>
			</tr>
		
		<?
			}
		
		?>
		</tbody>
	</table>
	
<?	
die();
}


?>

<? include('headerorg.php'); ?>


<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;Task Assign Master</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row" >

			<div class="col-sm-12">
			
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Id</label>
				<div class="col-sm-1">
				<?
				
					$qry="select max(id) from TaskAssignMaster";
					//echo $qry;
					$result=exequery($qry);
					$rowidno=fetch($result);
					if($rowidno!=null)
					$idno=$rowidno[0]+1;
				
				?>
				<input type="text" class="form-control" id="id" name="id" value="<?echo (($search == 1)? :$idno)?>">
				</div>
				<button class="btn" type="button" id='LookUpbutton' name='LookUpbutton' value='LookUp' onclick='LookUp();'>Lookup</button>
				</div><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Name</label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="fname" name="fname" >
				</div>
				</div><br><br>
				
			
				<div class="form-group">
					<label class='control-label col-sm-2'>Type </label>
					<div class="col-sm-4">
					
					<?
					$cnt=0;
					$selqry = "select * from TypeMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo"<table style='width:35%;'><tr><td>$selrow[1] <input type='hidden' name='typeids".$cnt."' id='typeids".$cnt."' value='$selrow[0]' /></td><td><input type='checkbox'  name='ptype".$cnt."' id='ptype".$cnt."' value='1' /></td></tr></table>";
					$cnt++;
					}
					?> 
					<input type="hidden"  value="<? echo $cnt ?>" name="cnt" id="cnt"/>
					</div>
				</div>
				
				
			</div>
      
			<div class="col-sm-2"></div>
			<div class="col-sm-10"><br><br>
				<button type="button" class="btn" type="button" id='AddorSearch' name='AddorSearch' value='Add' onclick='AddorUpdate();'>Add</button>
				<button type="button" class="btn" id='DeleteorSearch' name='DeleteorSearch' value='Search' onclick='DeleteSearch();'>Search</button>
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'TaskAssignMaster.php'">Cancel</button>
			
			</div>

	  </div>
	  
</div>

</div>
<div id='loadgid'></div>	
</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


</body>

<script type='text/javascript'>
function AddorUpdate()
{
	var id = $('#id').val();
	var fname = $('#fname').val();
	
	cnt = $('#cnt').val();
	 
	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	if(fname == ""){
		alert("Please Enter name");
		return false;
	}
	
	tempdata='';
	for(i=0;i<=cnt;i++)
	{
		if($("#ptype"+i).prop('checked') == true){
		
		temp=$('#typeids'+i).val();
		tempdata=tempdata+":"+temp;
		}
	}
	
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"TaskAssignMaster.php",
				data:"action="+actiontype+"&id="+id+"&fname="+fname+"&tempdata="+tempdata,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

function DeleteSearch()
{
	var id = $('#id').val();
	if(id == "")
	{
		alert("Please Enter id");
		return false;
	}
	
	var actiontype = $('#DeleteorSearch').val();
	$.ajax({
				url:"TaskAssignMaster.php",
				data:"action="+actiontype+"&id="+id,
				type:"post",
				success:function(output)
				{
				//alert(output);
					output1 = $.trim(output);
					if(output1 == "Notfound")
					{
						alert("Record not found");
						return false;
					}
					
					else if(output1 == "successfully")
					{
						alert("Record Deleted ...!!");
						window.location.reload(true);
						return false;
					}
					else{
						$("#id").prop("readonly", true);
						var store=output1.split('#');	
						$('#id').val(store[0]);
						$('#fname').val(store[1]);
						cnt =$('#cnt').val();
					    datatemp = store[2].split(':');
						
								  for(j=0;j<=cnt;j++)
									{
										for(i=0;i<=datatemp.length-1;i++)
								{
									
										if(datatemp[i]==$('#typeids'+j).val())
										{
											
											$("#ptype"+j).prop('checked',true);
										}
										
										
									}
								}
						
						$('#AddorSearch').val('Update');
						$('#AddorSearch').html('Update');
						$('#DeleteorSearch').val('Delete');
						$('#DeleteorSearch').html('Delete');
					
					}
					
				}
	});
	
}

function LookUp()
{
	 $("#loadgid").show();
	 $.ajax({
		url:"TaskAssignMaster.php",
		data:"action=loadgid1",
		type:"POST",
		success:function(output)
		{
			//alert(output);
			$('#loadgid').html(output);
			$("#mainform").hide();
			return false;
		}
	  });	
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteorSearch').val('Search');
		DeleteSearch();
}
</script>
</html>