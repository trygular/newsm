<html>
<head>
<a href="whatsapp://send?text=http://electionspecial.tarunbharat.com//NewsFeedsView.php?action=Generate&id=40" data-action="share/whatsapp/share">Share via Whatsapp</a>
</head>
</html>