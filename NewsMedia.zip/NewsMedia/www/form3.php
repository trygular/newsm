<? include('header.php'); ?>

<div class="well" style='border-top: Solid 4px #00BD9C;'>

<div class="panel panel-default">
<div class="panel-heading"><center><h3><a href="#" style='color:#00BD9C;font-size:24px;'>Tab System</a></h3></center></div>
<div class="panel-body">
	  
		<div class="row">
			
			<div class="col-sm-3">
		
			</div>

			<div class="col-sm-9">
			
			<ul class="nav nav-tabs">
			<li class="active"><a data-toggle="tab" href="#home">Home</a></li>
			<li><a data-toggle="tab" href="#menu1">Menu 1</a></li>
			<li><a data-toggle="tab" href="#menu2">Menu 2</a></li>
			<li><a data-toggle="tab" href="#menu3">Menu 3</a></li>
			</ul>

			<div class="tab-content">
			<div id="home" class="tab-pane fade in active">
			<h3>HOME</h3>
			<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
			</div>
			<div id="menu1" class="tab-pane fade">
			<h3>Menu 1</h3>
			<p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			</div>
			<div id="menu2" class="tab-pane fade">
			<h3>Menu 2</h3>
			<p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam.</p>
			</div>
			<div id="menu3" class="tab-pane fade">
			<h3>Menu 3</h3>
			<p>Eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.</p>
			</div>
			</div>
			</div>
			
		</div>

	  </div>			
</div>

</div>

</div><!------------------Well End here  ----------------------->


<!-----------------------Below divs are started on header.php ----------------------------->
		</div>
	</div>
</div>


<!------------------- Mobile menu Scripts  ------------------>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="../dist1/jquery.slicknav.js"></script>

<script type="text/javascript">
$(document).ready(function(){
$('#menu').slicknav();
});
</script>

<!------------------- Mobile menu Scripts  ------------------>
</body>
</html>