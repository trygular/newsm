<?
session_start();

include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');
/*
	PHP Name : CommentMaster.php
	Created Date : 29-03-2018
	Created By :  Abhinandan Budavi
*/
	if($_POST['action']=="HIDE"){
		
	 	$ridh=$_POST['ridh'];
		$qryh="UPDATE NeewsComments SET active='0'  WHERE refid='".$ridh."'   ";
		exequery($qryh);

		die();
	}
	if($_POST['action']=="SHOW"){
		
		$rids=$_POST['rids'];
		$qrys="UPDATE NeewsComments SET active='1'  WHERE refid='".$rids."'";		
		exequery($qrys);

		die();		
	}
	if($_POST['action']=="UPDATE"){
		
		$ridu=$_POST['ridu'];
		$comment=$_POST['comment'];		
		$qryu="UPDATE NeewsComments SET comment='".$comment."' WHERE refid='".$ridu."'";		
		exequery($qryu);
		
		$qryuc="SELECT comment FROM NeewsComments WHERE refid='".$ridu."' ";
		$rowhc=exequery($qryuc);
		$resuc=fetch($rowhc);
		
		echo $resuc[0];
		
		die();		
	}

?>


  <h2 style="margin-top:150px; padding-left:4%; padding-right:4%;" >NEWS COMMENTS</h2>
  <p style="padding-left:4%; padding-right:4%;" >BY STORY ID</p> 


 <div style="overflow-x:auto; padding-left:4%; padding-right:4%;">
   
<?

	$dep='';
    $qryresult="SELECT * FROM Newsfeeds N1,NeewsComments N2 WHERE N1.id=N2.storyid  group by N1.id order by N1.id ";
	$result = exequery($qryresult);
	while($row = fetch($result))
	{
		
		
		?>
		
		<table class="table table-bordered" > 
		<?	if($dep=='' || $dep!=$row[3]){
			echo "<thead>
			<tr><th colspan=4 style='text-align:left;font-size:18px;' >STORTY TITLE: ".$row[3]."</th></tr>
			 <tr><th colspan=4 style='text-align:left;font-size:18px;'>STORY ID: ".$row[0]."</th></tr>
			</thead>";
			$dep=$row[3];
		} ?>
		<thead>	
		<tr>      
		<th>COMMENTS</th>
		<th>USER</th>	
     
		<th style="text-align:center;" >HIDE/SHOW</th>
		<th style="text-align:center;" >UPDATE CHANGE</th>		
		</tr>
		</thead>
		<?
		
		$qryresult1="SELECT * FROM NeewsComments where storyid='".$row[0]."' ";
		$result1 = exequery($qryresult1);
		while($row1 = fetch($result1))
		{
							
		?>			
		<tbody>
		<tr>
        <td><textarea id='cmt<?echo $row1[6]?>' rows="4" cols="50"  name='cmt<?echo $row1[6]?>'   ><?echo $row1[1];   ?></textarea></td>
        <td><?echo $row1[2];   ?></td>	
     
		<td style="text-align:center;" >
		<?if($row1[7] == 1){
		echo "<button id='hide$row1[6]' name='hide$row1[6]' class='btn btn-primary' value='$row1[6]'   onclick='HIDEFUN(".$row1[6].");' >HIDE</button>";
		}else{
		echo "<button id='show$row1[6]' name='show$row1[6]' class='btn btn-primary' value='$row1[6]'   onclick='SHOWFUN(".$row1[6].");'  >SHOW</button>";
		}   ?>
		</td>	
		
		<td style="text-align:center;"  >
		<?
		echo "<button id='update$row1[6]' name='update$row1[6]' class='btn btn-primary' value='$row1[6]'   onclick='UPDATEFUN(".$row1[6].");' >UPDATE</button>";
		 ?>
		</td>	
		
		
		
		</tr>
		</tbody>
  
    <?
			}
	
	?>	 
  </table>
  
	<?
	}				
	?>
 </div>
	<br>
  <br>
  <br>
  <br>
	<?
 include('headerorg1.php');
 include('footer.php');
 ?>
 <script>
 function HIDEFUN(refid){
	 var ridh=$('#hide'+refid).val();
	$.ajax({
		url:"CommentMaster.php",
		data:"action=HIDE&ridh="+ridh,
		type:"POST",
		success:function(output){			
			$('#hide'+refid).attr('id','show'+refid);
			$('#show'+refid).attr('name','show'+refid);
			$('#show'+refid).attr('onclick','SHOWFUN('+refid+')');			
			$('#show'+refid).html('SHOW');
			
		}
	});	 
 }
 function SHOWFUN(refid){
	 var rids=$('#show'+refid).val();
	 
	$.ajax({
		url:"CommentMaster.php",
		data:"action=SHOW&rids="+rids,
		type:"POST",
		success:function(output){
			$('#show'+refid).attr('id','hide'+refid);
			
			$('#hide'+refid).attr('name','hide'+refid);
			$('#hide'+refid).attr('onclick','HIDEFUN('+refid+')');			
			$('#hide'+refid).html('HIDE');
			
					
		}
	});	 
 }
 
  function UPDATEFUN(refid){
	 var ridu=$('#update'+refid).val();
	var comment=$('#cmt'+refid).val();
	
	$.ajax({
		url:"CommentMaster.php",
		data:"action=UPDATE&ridu="+ridu+"&comment="+comment,
		type:"POST",
		success:function(output){
			$('#cmt'+refid).val($.trim(output));			
			//location.reload(true);
			//alert(output);
		}
	});	 
 }
 </script>
