<?php
  
  include("/etc/tbdconfig.php");
  mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
  usedb('DummyData');
	$id = $_GET['id'];
	$qrydelete= "delete from userSignin where id='".$_GET['id']."'";
	$res = exequery($qrydelete);
	?>
	<script>
	alert("Sure you want to delete!..");
	window.location="userfetch.php";
	</script>
	<?php
	
?>