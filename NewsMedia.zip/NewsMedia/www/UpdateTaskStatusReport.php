<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');

?>

<? include('headerorg.php'); ?>

<!------------------ start of datepicker scripts --------------------------------->
<link href="css/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
$( "#sdate" ).datepicker();	
});

$(function() {
$( "#pdate" ).datepicker();	
});

</script>
<!------------------ End of datepicker scripts --------------------------------->

<?

if($_GET['action'] == "search")
	{
			$qry="SELECT * FROM TaskStatusMaster where id='".$_GET['id']."'";
			//echo $qry;
			$res = exequery($qry);
			$rows = fetch($res);
			
			
			$qry1="SELECT * FROM TypeMaster ";
			$res1=exequery($qry1);
			while($row1=fetch($res1))
			{
				$qry2="SELECT * FROM TaskStatusMaster1 where tasktype='".$row1[0]."' and id='".$rows[0]."'";
				$res2=exequery($qry2);
				while($row2=fetch($res2))
				{
				   $qry3="SELECT * FROM TaskAssignMaster where id='".$row2[2]."'";
				   $res3=exequery($qry3);
				   $row3=fetch($res3);
			
				}

			}
		
	
					
				
				if($rows!=null)
				{
					$search=1;
				}
						
			/*
			{
				$qrynews="SELECT * FROM NewsMaster where id=".$rows[6]."";
				$resnews=exequery($qrynews);
				$rownews=fetch($resnews);
			
				$qrynews="SELECT * FROM NewsMaster where id=".$rows[6]."";
				$resnews=exequery($qrynews);
				$rownews=fetch($resnews);

				$qrysector="SELECT * FROM SectorMaster where id=".$rows[8]."";
				$ressector=exequery($qrysector);
				$rowsector=fetch($ressector);

				$qryp="SELECT * FROM PriorityMaster where id=".$rows[9]."";
				$resp=exequery($qryp);
				$rowp=fetch($resp);

				$qrys1="SELECT * FROM StatusTaskMaster where id=".$rows[11]."";
				$ress1=exequery($qrys1);
				$rows1=fetch($ress1);
				
				$qrysource="SELECT * FROM SourceMaster where id=".$rows[3]."";
				$ressource=exequery($qrysource);
				$rowsource=fetch($ressource);
				
				$qrysteam="SELECT * FROM TeamMaster where id=".$rows[4]."";
				$resteam=exequery($qrysteam);
				$rowteam=fetch($resteam);
			}*/
	}
	
	
	if($_POST['action'] =="Update")
	{
	
	
		$qry = "UPDATE TaskStatusMaster SET name='".mysql_real_escape_string($_POST['sname'])."',sdate='".DMYtoYMD($_POST['sdate'])."',source='".mysql_real_escape_string($_POST['source'])."',team='".mysql_real_escape_string($_POST['team'])."' ,pdate='".DMYtoYMD($_POST['pdate'])."',newstype='".mysql_real_escape_string($_POST['newstype'])."',videotime='".mysql_real_escape_string($_POST['vtime'])."',sector='".mysql_real_escape_string($_POST['sector'])."',priority='".mysql_real_escape_string($_POST['priority'])."',remark='".mysql_real_escape_string($_POST['remark'])."',status='".mysql_real_escape_string($_POST['status'])."' where id='".mysql_real_escape_string($_POST['id'])."'";
		
		echo $qry;
		
		/*$resq = exequery($qry);
	
			//$qrycoursedelete="delete from TaskStatusMaster1 where id='".$_POST['id']."'";
			//exequery($qrycoursedelete);
			
					$data = $_POST['tempdata'];
					$maindata = explode(':',$data);
					foreach($maindata as $datacourse) 
					{
						$maindata1 = explode('#',$datacourse);
						if ($maindata1[0]!="")
						{
							//$qrycourse="insert into TaskStatusMaster1(id, tasktype, name) values ('".$_POST['id']."','".$maindata1[0]."','".$maindata1[1]."')";
							//exequery($qrycourse);
							//echo $qrycourse;
						}
					}
				?>			
				<script>
				alert("Record Update Successfully");
				//window.location.href = 'UpdateTaskStatusReport.php';
				</script>
				<?*/
				
		die();
	}
?>
<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<form action="UpdateTaskStatusReport.php" method="POST">
<div class="panel panel-default" style="width:80%;margin-left:10%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp; Task Status Report</a></h3></center></div>
<div class="panel-body">
	  
	<div class="row" >
	
			<div class="col-sm-12">
			
			
				<div class="form-group">
				<label class='control-label col-sm-2'>Sl.No</label>
				<div class="col-sm-1">
				<input type="text" class="form-control" name="id" id="id" value="<? echo (($search==1)?$rows[0]:"") ?>" >
				</div>

				</div><br>
				
			<div class="form-group">
					<label class='control-label col-sm-2'>Story Name</label>
				<div class="col-sm-4">
				<input type="text" class="form-control" id="sname"  name="sname"  value="<? echo $rows[1] ?>" >
				</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Assign Date</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="sdate" name="sdate" placeholder="" value="<? echo YMDtoDMY($rows[2]) ?>" >
				</div>
				</div><br><br>
				
			
				<div class="form-group">
					<label class='control-label col-sm-2'>Source Name</label>
					<div class="col-sm-4">
					<select class="form-control" id="source" name="source" >
					<?
					
					if($search==1)
					{
						$selqry = "select * from SourceMaster where id='".$rows[3]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
					$selqry = "select * from SourceMaster where active='1' ";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
			
				
				<?
					$i=0;
					$selqry = "select * from TypeMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
				?>
						
					<div class="form-group">
					<label class='control-label col-sm-2'><? echo $selrow[1]?></label>
					<div class="col-sm-4">
					<select class="form-control" id="tasktype<?echo $i;?>" name="tasktype<?echo $i;?>">
					
					<?		
							if($search==1)
							{
								
								$qry1="SELECT * FROM TypeMaster  where active='1' ";
								$res1=exequery($qry1);
								while($row1=fetch($res1))
									{
										$qry2="SELECT * FROM TaskStatusMaster1 where tasktype='".$row1[0]."' and id='".$rows[0]."'";
										$res2=exequery($qry2);
										echo $qry2."<br>";
										while($row2=fetch($res2))
											{
												$qry3="SELECT * FROM TaskAssignMaster where id='".$row2[2]."'";
												echo $qry3."<br>";
												$res3=exequery($qry3);
												$row3=fetch($res3);
												
	
											}
											echo "<option value='".$row3[0]."'>".$row3[1]."</option>";
									}	
							 }
					
							//echo "<option value='Select'>Select</option>";
							$selqry1 = "select * from TaskAssignMaster T, TaskAssignMaster1 T1, TypeMaster M where T.id=T1.id and T1.typename=M.id and M.id='".$selrow[0]."'";
							$selres1 = exequery($selqry1);
							while($selrow1 = fetch($selres1))
							{
								echo "<option value='".$selrow1[0]."'>".$selrow1[1]."</option>";
							}
					?>
					</select>
					
					</div>
					</div><br><br>
					<input type="hidden" class="form-control" id="typeid<?echo $i;?>" name="typeid<?echo $i;?>" value="<?echo $selrow[0]?>" >
				<?
				
				$i++;
					}
					
				?>
				<input type="hidden" class="form-control" id="maincnt" name="maincnt" value="<?echo $i?>" >
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Team</label>
					<div class="col-sm-4">
					<select class="form-control" id="team" name="team" >
					<?
					
					if($search==1)
					{
						$selqry = "select * from TeamMaster where id='".$rows[4]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
					
					$selqry = "select * from TeamMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Publish Date</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="pdate" name="pdate" placeholder="" value="<? echo YMDtoDMY($rows[5]) ?>">
				</div>
				</div><br><br>
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>News Type </label>
					<div class="col-sm-4">
					<select class="form-control" id="newstype" name="newstype" >
					<?
					
					if($search==1)
					{
						$selqry = "select * from NewsMaster where id='".$rows[6]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
					
					$selqry = "select * from NewsMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Video Time</label>
				<div class="col-sm-2">
				<input type="text" class="form-control" id="vtime" name="vtime" placeholder="hh:mm:ss" value="<? echo $rows[7] ?>">
				</div>
				</div><br><br>
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Sector</label>
					<div class="col-sm-4">
					<select class="form-control" id="sector" name="sector">
					<?
					
					if($search==1)
					{
						$selqry = "select * from SectorMaster where id='".$rows[8]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
					
					$selqry = "select * from SectorMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				
				<div class="form-group">
					<label class='control-label col-sm-2'>Priority</label>
					<div class="col-sm-4">
					<select class="form-control" id="priority" name="priority" >
					<?
					
					if($search==1)
					{
						$selqry = "select * from PriorityMaster where id='".$rows[9]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
					
					$selqry = "select * from PriorityMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
				<div class="form-group">
				<label class='control-label col-sm-2'>Remark</label>
				<div class="col-sm-4">
				<textarea class="form-control" rows="3" id="remark" name="remark"><? echo $rows[10] ?></textarea>
				</div>
				</div><br><br><br><br><br>
				
			
					<div class="form-group">
					<label class='control-label col-sm-2'>Status </label>
					<div class="col-sm-4">
					<select class="form-control" id="status"  name="status">
					<?
					
					if($search==1)
					{
						$selqry = "select * from StatusTaskMaster where id='".$rows[11]."' ";
						$selres = exequery($selqry);
						while($selrow = fetch($selres))
						{
							echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
						}
					}
					
				
					$selqry = "select * from StatusTaskMaster where active='1'";
					$selres = exequery($selqry);
					while($selrow = fetch($selres)){
					echo "<option value='".$selrow[0]."'>".$selrow[1]."</option>";
					}
					?>
					</select>
					</div>
				</div><br><br>
				
			</div>
      
			<div class="col-sm-2"></div>
			
			<div class="col-sm-10"><br><br>
				&nbsp;&nbsp;&nbsp;
				<button type="button" class="btn" id='Update' name='Update' value='Update' onclick="UpdateData();">Update</button>
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'TaskStatusReport.php'">Cancel</button>
			
			</div>
		
	  </div>
	  
</div>

</div>
<div id='loadgid'></div>	
		</div>
		</form>
	</div>
</div>

</body>

<script>
function UpdateData()
{
	//alert('hi');
	
	var id = $('#id').val();
	var sname = $('#sname').val();
	var sdate = $('#sdate').val();
	var source = $('#source').val();
	var team = $('#team').val();
	var pdate = $('#pdate').val();
	var newstype = $('#newstype').val();
	var vtime = $('#vtime').val();
	var sector = $('#sector').val();
	var priority = $('#priority').val();
	var remark = $('#remark').val();
	var status = $('#status').val();
	
	
	maincnt = $('#maincnt').val();
	tempdata='';
	for(i=0;i<=maincnt;i++)
	{
		temp=$('#tasktype'+i).val();
		temp1=$('#typeid'+i).val();
		tempdata=tempdata+":"+temp1+"#"+temp;
		
	}
	//alert (tempdata);
	//die();

	if(id == ""){
		alert("Id id is Blank");
		return false;
	}
	
	if(sname == ""){
		alert("Please Enter Story Name");
		return false;
	}
	
	if(sdate == ""){
		alert("Please Enter Assign Date");
		return false;
	}
	
	if(source == "Select"){
		alert("Please Select Source");
		return false;
	}
	
	if(team == "Select"){
		alert("Please Select Team");
		return false;
	}
	
	if(pdate == ""){
		alert("Please Enter Publish Date");
		return false;
	}
	
	if(newstype == "Select"){
		alert("Please Select News Type");
		return false;
	}
	
	if(sector == "Select"){
		alert("Please Select Sector");
		return false;
	}
	
	if(priority == "Select"){
		alert("Please Select Priority");
		return false;
	}
	
	
	if(status == "Select"){
		alert("Please Select Status");
		return false;
	}
	

	var actiontype = $('#AddorSearch').val();
	$.ajax({
				url:"UpdateTaskStatusReport.php",
				data:"action=Update&id="+id+"&sname="+sname+"&sdate="+sdate+"&source="+source+"&team="+team+"&pdate="+pdate+"&newstype="+newstype+"&vtime="+vtime+"&sector="+sector+"&priority="+priority+"&remark="+remark+"&status="+status+"&tempdata="+tempdata,
				type:"post",
				success:function(output)
				{
					alert(output);
					window.location.reload(true);
				}
	});
	
}

</script>

</html>