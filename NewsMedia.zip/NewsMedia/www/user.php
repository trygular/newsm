<?php
  include("/etc/tbdconfig.php");
	mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
	usedb('DummyData');
	?>
<!DOCTYPE html>
<html lang="en">

<head>
<title>Tarun Bharat</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">@import url("style.css");</style>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"> 
	<link rel="stylesheet" type="text/css" href="css/datatables.min.css">
	<link rel="stylesheet" href="css/style.css">
   <!-- <link href='default.css' rel='stylesheet' type='text/css' />-->
    <script type="text/javascript" src="js/jsapi.js"></script>
    <script src="js/script.js" type="text/javascript"></script>
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="dist/css/bootstrap-select.css">
	<!--<link rel="stylesheet" href="font/font-awesome.min.css" type="text/css" />-->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	
	<!-------------------datepicker files  are as follows 
	<link href="css/ji.csquery-us" rel="stylesheet">------------------>
	

	<script src="dist/js/bootstrap-select.js"></script>
 
	<script src="js/jquery-1.10.2.js"></script>
	<script src="js/jquery-ui.js"></script>
	
	<script>
	$(function() {
	$( "#pdate" ).datepicker();	
	});
	</script>
	



<script>
$(document).ready(function(){
    $("#btn1").click(function(){
        $(".container").css({"width": "100%"});
    });
});
</script>

<script>
$(document).ready(function(){
    $("#btn2").click(function(){
        $(".container").css({"width": "75%"});
    });
});
</script>

<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>
<!--------------------------  Script for wide and box container End  ----------------------------------->




<style> 
 body{
   //background-image: url("images/1680x1050-light-steel-blue-solid-color-background.jpg");
   height:auto;
   width:auto;
}
/*bootstrap class override for login page only*/
	.form-control{
		border-radius: 9px;
		margin: 12px 3px;
		height: 40px;
	}
	.logo{
		margin: auto;
		text-align: center;
		padding-top: 20%;
	}
	.logo img{
		height: 60px;
	}
	/*footer*/ 
	.footer a{
		color: #000;
		text-decoration: none;
	}
	.footer{
		color: #000;
		text-align: center;
	}
	/*footer end*/ 


	/*for logintemplate blue*/
	.grayBody{
		background-color: #E9E9E9;
	}
	.loginbox{
		margin-top: 5%;
		border-top: 6px solid #cc470d;
		background-color:#dddada;
		padding: 20px;
		box-shadow: 0 10px 10px -2px rgba(0,0,0,0.12),0 -2px 10px -2px rgba(0,0,0,0.12);    
	}
	.singtext{    
		font-size: 28px;  
		color: #111517;
		font-weight: 500;
		letter-spacing: 1px;
	}
	.submitButton{
		background-color: #cc470d;
		color: #fff;
		margin-top: 12px;
		margin-bottom: 10px;
		padding: 10px 0px;
		width: 100%;
		margin-left: 2px;
		font-size: 16px;
		border-radius: 0px;
		outline: none;
	}
	.submitButton:hover,.submitButton:focus{
		color: #fff;  
		outline: none;
	}
	.forGotPassword{
		background-color: #544646; 
		padding: 15px 0px;
		text-align: center;

	}
	.forGotPassword:hover{
		 box-shadow: 0 10px 10px -2px rgba(0,0,0,0.12);    
	}
	.forGotPassword a{
		color: #f2e7e7;
		outline: none;
	}
	.forGotPassword a:hover, .forGotPassword a:active,.forGotPassword a:focus{  
		text-decoration: none; 
		outline: none;
	}
</style>

<link href="css/bootstrap-glyphicons.css" rel="stylesheet" /> 
<!------------------ start of datepicker scripts --------------------------------->
<link href="css/jquery-ui.css" rel="stylesheet">
<script src="js/jquery-1.10.2.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
$(function() {
$( "#doj" ).datepicker();	
});
</script>
<!------------------ End of datepicker scripts --------------------------------->
</head>

<body style="background-color:#f9f6f6">

   <div class="container">
   
         <form method="post" action="check.php">   
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="logo">
                    <img src="images/logoorg.png"  alt="Logo"  > 
                </div>
                <div class="row loginbox">                    
                    <div class="col-lg-12">
                        <center><span class="singtext" >Sign Up </span></center> 
                    </div>
                     <div class="col-lg-12 col-md-12 col-sm-12">
                        <input class="form-control" name="fname" type="text" placeholder="Fullname" > 
                    </div>
					<div class="col-lg-12 col-md-12 col-sm-12">
                        <input class="form-control" name="doj"  id="doj" type="text" placeholder="Date of birth" > 
                    </div>
                   
					 <div class="col-lg-12 col-md-12 col-sm-12">
                        <input class="form-control" name="email" type="text" placeholder="Email Id" > 
                    </div>
					 <div class="col-lg-12 col-md-12 col-sm-12">
                        <input class="form-control" name="mobileno" type="text" placeholder="Mobileno" > 
                    </div>
                                       
                     <div class="col-lg-12 col-md-12 col-sm-12">
                        <input class="form-control" name="username" type="text" placeholder="User name" required="required" > 
                    </div>
                    <div class="col-lg-12  col-md-12 col-sm-12">
                        <input class="form-control" name="password" type="password" placeholder="Password" required="required">
                    </div>
					 <div class="col-lg-12  col-md-12 col-sm-12">
					<input type="hidden" name="submit" value="submit">
                       <button class="btn  submitButton">Submit </a> 
                    </div> 
                </div>
                <div class="row forGotPassword">
                    <a href="login.php" >Sign In </a> 
                </div>
                <br>                
                <br>
           </div>
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
        </div>
	</form>	

</body>	

