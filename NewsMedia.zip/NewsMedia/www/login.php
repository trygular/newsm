<?php
  include("/etc/tbdconfig.php");
	mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
	usedb('DummyData');
 require 'class.phpmailer.php';
	?>
  <?php

   if($_POST['Action']=="getemail")
	{ 
        $qry ="SELECT * FROM userSignin where username='".$_POST['username']."'";
		//echo $qry;
		$res = exequery($qry);
		$rows = fetch($res);
		
		$pos = explode('@',$rows[3]);
		$pos1 = substr($pos[0],0,3);	
		$pos2 = substr($pos[0],3);
		$lenthstr= strlen($pos2);
		
		for($rep=0;$rep<$lenthstr;$rep++)
		{
			$charappend =$charappend."*";
		}
		$emailfin = $pos1.$charappend."@".$pos[1];
		echo $emailfin.":".$rows[3];
		
	}	
	if($_POST['Action']=="sendpassword1")
	{
	
		    $username = $_POST['username'];
		    //$password = $_POST['password'];
			//$password=password($_POST['password']);
			$sql = "SELECT * FROM userSignin WHERE username = '".$_POST['username']."'";
			$res = exequery($sql);
	       // echo $sql;

			$rows = fetch($res);
			
			//$password1=$rows[6];
			//$password = md5($rows[6]);
      			
			//$password = $rows[6];
			$to = $rows[3];
			$chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%&*_";
            $password = substr(str_shuffle($chars), 0, 6);
            $subject = "Your Recovered Password";

            $message = "Please use this password to login:"  . $password ;
		    $message1 =  "username is :" . $username ;
            $headers = "From : lonicatelis.05@gmail.com";
            if(mail($to, $subject, $message, $message1, $headers)){
			$sqlupdate = "update userSignin set password=password('".$password."') WHERE username='".$_POST['username']."'";
			$res = exequery($sqlupdate);
			echo $sqlupdate;
	        //echo "Your Password has been sent to your email id";
			}else{
				echo "Failed to Recover your password, try again";
			}
			
						
	}
		
	if(isset($_POST['submit']))   //checking the 'user' name which is from Sign-Up.html, is it empty or have some text
	{
		$msg="asf";
		$usersql = "SELECT * FROM userSignin WHERE username = '".$_POST['username']."' AND password = password('".$_POST['password']."')";
        $res = exequery($usersql);
     
		if(! $row = fetch($res))
		{
			header('location:login.php');
			//echo $msg;
		}
		else
		{
			header('location:index.php');
			echo "SORRY...YOU ARE ALREADY REGISTERED USER...";
		}
	
	}
	?>
	<script>
	function getemail()
	{

		 username=$('#username1').val();
	//alert(username);
		 $.ajax({
					url: "/login.php" ,
					data: "Action=getemail&username="+username,
					type : 'POST',
					success: function(output)
					{
						
						outputdata=output.split(':');
						$('#email').val(outputdata[0]);
						$('#orgemail1').val(outputdata[1]);
						
					}
				});

	}

	function sendpassword1()
	{
		 u=$('#username1').val();
		
		 email=$('#orgemail1').val();
		 
	 // alert(u);
	 //alert(email);
		 
		 $.ajax({
					url: "/login.php" ,
					data: "Action=sendpassword1&username="+u+"&email="+email,
					type : 'POST',
					success: function(output)
					{
						alert(output);
						$('#email').val('');
						$('#username1').val('');
						$('#orgemail1').val('');
					
						
					}
				});

	}
	</script>

	
<!DOCTYPE html>
<html lang="en">

<head>
<title>Tarun Bharat</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style type="text/css">@import url("style.css");</style>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css"> 
	<link rel="stylesheet" type="text/css" href="css/datatables.min.css">
	<link rel="stylesheet" href="css/style.css">
   <!-- <link href='default.css' rel='stylesheet' type='text/css' />-->
    <script type="text/javascript" src="js/jsapi.js"></script>
    <script src="js/script.js" type="text/javascript"></script>
	<!--<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">-->
    <link rel="stylesheet" href="dist/css/bootstrap-select.css">
	<!--<link rel="stylesheet" href="font/font-awesome.min.css" type="text/css" />-->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	
	<!-------------------datepicker files  are as follows 
	<link href="css/ji.csquery-us" rel="stylesheet">------------------>
	

	<script src="dist/js/bootstrap-select.js"></script>
 
	<script src="js/jquery-1.10.2.js"></script>
	<script src="js/jquery-ui.js"></script>
	
	<script>
	$(function() {
	$( "#pdate" ).datepicker();	
	});
	</script>
	



<script>
$(document).ready(function(){
    $("#btn1").click(function(){
        $(".container").css({"width": "100%"});
    });
});
</script>

<script>
$(document).ready(function(){
    $("#btn2").click(function(){
        $(".container").css({"width": "75%"});
    });
});
</script>

<script> 
$(document).ready(function(){
    $("#flip").click(function(){
        $("#panel").slideToggle("slow");
    });
});
</script>
<!--------------------------  Script for wide and box container End  ----------------------------------->




<style> 
 body{
   //background-image: url("images/1680x1050-light-steel-blue-solid-color-background.jpg");
   height:auto;
   width:auto;
}
/*bootstrap class override for login page only*/
	.form-control{
		border-radius: 9px;
		margin: 12px 3px;
		height: 40px;
	}
	.logo{
		margin: auto;
		text-align: center;
		padding-top: 20%;
	}
	.logo img{
		height: 60px;
	}
	/*footer*/ 
	.footer a{
		color: #000;
		text-decoration: none;
	}
	.footer{
		color: #000;
		text-align: center;
	}
	/*footer end*/ 


	/*for logintemplate blue*/
	.grayBody{
		background-color: #E9E9E9;
	}
	.loginbox{
		margin-top: 5%;
		border-top: 6px solid #cc470d;
		background-color:#dddada;
		padding: 20px;
		box-shadow: 0 10px 10px -2px rgba(0,0,0,0.12),0 -2px 10px -2px rgba(0,0,0,0.12);    
	}
	.singtext{    
		font-size: 28px;  
		color: #111517;
		font-weight: 500;
		letter-spacing: 1px;
	}
	.submitButton{
		background-color: #cc470d;
		color: #fff;
		margin-top: 12px;
		margin-bottom: 10px;
		padding: 10px 0px;
		width: 100%;
		margin-left: 2px;
		font-size: 16px;
		border-radius: 0px;
		outline: none;
	}
	.submitButton:hover,.submitButton:focus{
		color: #fff;  
		outline: none;
	}
	.forGotPassword{
		background-color: #544646; 
		padding: 15px 0px;
		text-align: center;

	}
	.forGotPassword:hover{
		 box-shadow: 0 10px 10px -2px rgba(0,0,0,0.12);    
	}
	.forGotPassword a{
		color: #f2e7e7;
		outline: none;
	}
	.forGotPassword a:hover, .forGotPassword a:active,.forGotPassword a:focus{  
		text-decoration: none; 
		outline: none;
	}
	.js #manage_reply_enquiry {
    display:none; /* hide for JS enabled browsers */
}
#manage_reply_enquiry {
    /* form styles here */
}
</style>

<link href="css/bootstrap-glyphicons.css" rel="stylesheet" /> 
</head>

<body style="background-color:#f9f6f6">

   <div class="container">
   
  <form method="post" action="login.php">  

	 <div class="myclassname"> 
          <div class="col-lg-4 col-md-3 col-sm-2"></div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="logo">
                    <img src="images/logoorg.png"  alt="Logo"  > 
                </div>
                <div class="row loginbox">                    
                    <div class="col-lg-12">
                        <center><span class="singtext" >Sign in </span></center> 
                    </div>

                   <div class="col-lg-12 col-md-12 col-sm-12">
                       <input class="form-control" id="username" name="username" value='' type="text" placeholder="User name" > 
                   </div>
                   <div class="col-lg-12  col-md-12 col-sm-12">
                        <input class="form-control" id="password" name="password" value='' type="password" placeholder="Password" >
                    </div>
                    <div class="col-lg-12  col-md-12 col-sm-12">
					   <input type="hidden" name="submit" value="submit">
                       <button class="btn  submitButton">Submit </a> 
                    </div>                     
                </div>
                <div class="row forGotPassword">
                  <a class="reply" href="#manage_reply_enquiry">Forgot Password click here</a>
                </div>
                <br>                
                <br>


            </div>
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
        </div>
	</div>
 </form>	
	

    <form id="manage_reply_enquiry" method="POST" action="login.php">
         <div class="col-lg-4 col-md-3 col-sm-2"></div>
            <div class="col-lg-4 col-md-6 col-sm-8">
                <div class="logo">
                    <img src="images/logoorg.png"  alt="Logo"  > 
                </div>
                <div class="row loginbox">                    
                  <div class="col-lg-12 col-md-12 col-sm-12">
				      <input class="form-control" id="username1" name="username1" value='' type="text" placeholder="Username" onchange='getemail();'> 
                   </div>
                  <div class="col-lg-12 col-md-12 col-sm-12">
				      <input class="form-control" name="email" id="email" value=''  type="text" placeholder="Email Id" > 
					  
					   <input class="form-control" name="orgemail1" value='' id="orgemail1" type="hidden" placeholder="Email Id" > 
                   </div>
				
				<div class="col-lg-12  col-md-12 col-sm-12">
					 <button type="button" class="btn  submitButton" value='' onclick='sendpassword1()'>Submit </a></button> 
                </div> 
                </div>
                <div class="row forGotPassword">
                    <a href="login.php" >Sign In </a> 
                </div>
                <br>                
                <br>
           </div>
            <div class="col-lg-4 col-md-3 col-sm-2"></div>
        </div>
  </form>

	<script type="text/javascript">
	//If JS is enabled add a class so we can hide the form ASAP (and only for JS enabled browsers)
	document.documentElement.className = 'js';
	//add the jQuery click/show/hide behaviours:
	$(document).ready(function(){
		 $(".reply").click(function(){
			 if($("#manage_reply_enquiry").is(":visible")){
			   $("#manage_reply_enquiry").hide();
			} else {
			   $("#manage_reply_enquiry").show();
			}
			//don't follow the link (optional, seen as the link is just an anchor)
			return false;
		 });
	  });
	</script>


</body>	