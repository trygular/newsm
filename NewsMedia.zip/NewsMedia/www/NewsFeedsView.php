<?

session_start();
?>

<?
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');
/*
	PHP Name : NewsFeedsMaster.php
	Created Date : 24-03-2018
	Created By :  Abhinandan Budavi
*/

 
if($_POST['action'] == 'POSTCOMMENT'){
	
	
	$sid=$_POST['sid'];	
	//echo $sid;
	//echo"hi";
	//die();
	$comment = $_POST['comment'];
	
	$name = $_POST['name'];
		
	$address = $_POST['address'];	
	
	$mobno = $_POST['mobno'];	

	
	
	$maxidno="select max(cid) from NeewsComments";
	$rs=exequery($maxidno);
	$out=fetch($rs);
	if($out[0]!=null)
		$idmax=$out[0]+1;	
	else{
		$idmax =1;
	}
	
	
	
	$qryins="INSERT INTO NeewsComments (cid, comment, name, address, mobileno, storyid) VALUES('".$idmax."','".$comment."', '".$name."', '".$address."','".$mobno."','".$sid."')";
	exequery($qryins);
	
	die();
}


?>
<meta
charset="UTF-8" />
<style>
@font-face {
font-family:'marathi';
src: local('TBDTarun2'),
	local('TBDTarun2'),
	url('/tbdtaru2.ttf') format('truetype');
}
.marathilanguage {font-family:'marathi'; font-size:32};
.englishlanguage {font-size:16; font-family:"arial",arial,serif;};
</style>
<?
//if( $_GET['action']  == "Generate" )
{




$qry = "select * from Newsfeeds where id='".$_GET['id']."' ";
$res = exequery($qry);
$row = fetch($res);

	?>

<img src="longads.gif" alt="Adds" class="responsive"  style='margin-top:120px; padding:5%; width:100%'  > 	
<header class="w3-container w3-center w3-padding-32" style='margin-top:20px;' > 
  <h1><b><? echo $row[3]?></b></h1>
</header>	

<?
		$substrcont=0;
		$qry2="SELECT * FROM Newsfeeds1 where id='".$_GET['id']."'";
		$res2= exequery($qry2);
		while($rows2=fetch($res2))
		{
			
			?>
			
			<img src="<? echo $rows2[2]; ?>" alt="Adds" class="responsive"  style='margin-top:<?echo $bit;?>px; padding:5%;  width:100%;'  > 
			<?
			if($substrcont==0)
			{
			?>	
			<div style='padding:5%;' ><p style="font-size:5vw;   "><?echo  $row[4]; ?></p></div>
			<?
			}
			 $substrcont++;
		}	
	
	
		
?>


<img src="longads.gif" alt="Adds" class="responsive"  style='margin-top:20px; padding:5%; width:100%;' > 

<br>


 <div class="w3-card w3-margin">
    <div class="w3-container w3-padding">
      <h4 style='color:#cc470d;font-size:14px; text-align:left' >RELEATED NEWS</h4>
    </div>
    <ul class="w3-ul w3-hoverable w3-white">


<?

$str = explode(",",$row[5]);
$len=sizeof($str);

$varid="";

for($i=0;$i<=$len; $i++){
	//$temp=$i%2;
	
	$qry3 = "select * from Newsfeeds where id!='".$row[0]."' and tags like '%".$str[$i]."%' $varid order by date desc";
	$res3 = exequery($qry3);
	$row3 = fetch($res3);
	if($row3!=null)
	{	
	$qry4 = "select * from Newsfeeds1 where id='".$row3[0]."'";
	$res4 = exequery($qry4);
	$row4 = fetch($res4);
	
	
?>

		<a href='http://newsmedia.tarunbharat.co.in/NewsFeedsView.php?action=Generate&id=<?echo $row3[0]?>' > 
		<li class="w3-padding-16 w3-hide-medium w3-hide-small">
		<table>
		<tr><td>
        <img src="<?echo $row4[2]; ?>" alt="Image" class="w3-left w3-margin-right" style="height:75px; width:80px; margin-left:2%; ">
		</td><td>&nbsp;&nbsp;&nbsp;</td><td valign='top'>
        <?echo "Date:" .$row3[1]." ".$row3[2]."<br>".$row3[3]?> 
		</td></tr>
		</table>
        <span><hr></span>
		</li></a> 
  
<?	
	$varid=$varid." and id !='".$row3[0]."'";
	}
	}
	
	
 ?>
 
   </ul>
  </div>

<img src="longads.gif" alt="Adds" class="responsive"  style='margin-top:20px; padding:5%; width:100%;' >
<br>
<br>


<div class="panel panel-default" style="width:100%;" id='mainform'>
<div class="panel panel-default"><h3 style='color:#cc470d;font-size:14px; text-align:left' >&nbsp;&nbsp;&nbsp;COMMENTS</h3></div>
 
<div class="panel-body">
 <table width='100%'>
 
 
<?
$k=1;
		$qry3="SELECT * FROM NeewsComments where storyid='".$_GET['id']."' and active=1";
		$res3= exequery($qry3);
		while($rows3=fetch($res3))
		{
		    $k++;
		    if(($k%2)==0)
		    $color='brown';
		    else
		    $color='blue';
		    
			
			 		
						echo "<tr><td width=15% align='right'><img src='man.png' width='30%' height='30%'></img></td><td width=5%>&nbsp;&nbsp;</td><td width=85%><font color='.$color.' size=3>".$rows3[2]." : <br> </font>"; ?>
						 
						<?echo $rows3[1]."</td></tr><tr><td colspan=2><hr></td></tr>"; ?>	
				
 
		<?
		}
?>
 </table>
 </div>
<div class="panel-body">
	<form class="form-horizontal">
<fieldset>

<!-- <legend>YOUR COMMENT</legend>  Form Name -->


<!-- Text input-->
<div class="form-group" style='display:none'>
  <label class="col-md-4 control-label" for="sid">ID</label>  
  <div class="col-md-4">
  <input id="sid" name="sid" placeholder="Id" class="form-control input-md" required="" value="<?echo $_GET['id'];?>" type="text">
    
  </div>
</div>

<!-- Textarea -->
<div class="form-group">
  <label class="col-md-4 control-label" for="comment">COMMENTS</label>
  <div class="col-md-4">                     
    <textarea class="form-control" id="comment" name="comment"></textarea>
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="textinput">NAME</label>  
  <div class="col-md-4">
  <input id="name" name="name" placeholder="Your Name" class="form-control input-md" required="" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="address">E-MAIL</label>  
  <div class="col-md-4">
  <input id="address" name="address" placeholder="Your E-Mail Id" class="form-control input-md" required="" type="text">
    
  </div>
</div>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="mobno">MOBILE NO</label>  
  <div class="col-md-4">
  <input id="mobno" name="mobno" placeholder="Your Mobile Number" class="form-control input-md" required="" type="text">
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for="postcmt"></label>
  <div class="col-md-4">
    <input id="postcmt" name="postcmt" class="btn btn-primary" value='POSTCOMMENT'   onclick='POSTCOMMENTFUN();'  />
  </div>
</div>

</fieldset>
</form>  
	
</div>
<br>
<br>
<script>

function POSTCOMMENTFUN()
{
	//alert('hello');
	//return false;
	
	var postdata=$('#postcmt').val();
	var sid =$('#sid').val();
	
	var comment = $('#comment').val();
	
	if(comment == ''){
		alert("Comment Can't Be Empty!!!");
		return false;
	}
	
	var name = $('#name').val();
	if(name == ''){
		alert("Name Can't Be Empty!!!");
		return false;
	}
	
	
	
	var address = $('#address').val();
	
	
	var mobno = $('#mobno').val();
	if(mobno == ''){
		alert("Mobile Number Can't Be Empty!!!");
		return false;
	}

	
	
	var formData = new FormData();
	formData.append('action', postdata);
	formData.append('sid', sid);
	formData.append('comment', comment);
	formData.append('name', name);
	formData.append('address', address);
	formData.append('mobno', mobno);
	
		$.ajax({
		url:"NewsFeedsView.php",
		type:"POST",
		data : formData,
		processData: false, 
		contentType: false,  
		
		success:function(output)
		{
			//alert($.trim(output));
			window.location.reload();
		}
		
		});
}
</script>

<? 
 include('headerorg1.php');
 include('footer.php');
die();
}
?>

