<?
session_start();
include("/etc/tbdconfig.php");
mysql_connect($mysql_temperp_host,$mysql_temperp_user,$mysql_temperp_password);
usedb('NewsMedia');
/*
	PHP Name : NewsFeedsMaster.php
	Created Date : 23-03-2018
	Created By :  Abhinandan Budavi
*/

if($_POST['action'] == 'deletefile'){
		//echo $_POST['fileid'];
		$qrysel ="SELECT id,filepath FROM Newsfeeds1 WHERE fid='".$_POST['fileid']."'";
		$ressel = exequery($qrysel);
		$rowsel = fetch($ressel);
		
		unlink($rowsel['filepath']);
		
		$qrydel ="DELETE from Newsfeeds1 WHERE fid='".$_POST['fileid']."'";
		exequery($qrydel);
		
		
		echo "del";
		die();
}





if($_POST['action']=="Add"){
	
	//echo 'hi';
	//die();
	$id=$_POST['id'];
	
	$date=DMYtoYMD($_POST['date']);
	
	$time = $_POST['time'];
	
	$matter = $_POST['matter'];

	$title = $_POST['title'];
	
	$tags = $_POST['tags'];	
		

	
	$a = $_POST['a'];
	
	$maxidno="select max(id) from Newsfeeds";
	$rs=exequery($maxidno);
	$out=fetch($rs);
	if($out[0]!=null)
		$idmax=$out[0]+1;	
	else{
		$idmax =1;
	}
	
	
	$qryins="INSERT INTO Newsfeeds (id, date, time, title, matter, tags) VALUES('".$idmax."','".$date."', '".$time."', '".mysql_escape_string($title)."','".mysql_escape_string($matter)."','".$tags."')";
	
	exequery($qryins);
	
	
	 $maxqry = "select max(fid) from Newsfeeds1";
		$maxres = exequery($maxqry);
		$maxrow = fetch($maxres);
		if($maxrow[0]!=null)
		$idmax2=$maxrow[0]+1;	
		else{
			$idmax2 =1;
		}
		
		
				
		for($f=0; $f < $a; $f++)
		{
			//$fileParts=pathinfo($_FILES['fileattach0']['name']);
			if($_FILES['fileattach'.$f] !== ""){
				if ( 0 < $_FILES['fileattach'.$f]['error'] ){
					echo 'Error: ' . $_FILES['fileattach'.$f]['error'] . '<br>';
				}
				else{
					$fileParts = pathinfo($_FILES['fileattach'.$f]['name']);
					$attaddfile = 'NewsFeeds/'.$idmax.'_'.$idmax2.'_'.$f.'.'. $fileParts['extension'];
					move_uploaded_file($_FILES['fileattach'.$f]['tmp_name'], $attaddfile);
					
					$qryin1 = "INSERT INTO Newsfeeds1 (fid, id, filepath) VALUES('".$idmax2."','".$idmax."','".$attaddfile."')";
					exequery($qryin1);
					//echo $_FILES['attaddfile']['name'];
					$idmax2++;
				}
			}
		}
	
	
		
	
	echo "Added Succussfully!!!";
	
	die();
}




if($_POST['action']=="Search"){
	//$id=$_POST['id'];
	
	
	$seqry = "SELECT * from Newsfeeds where id='".$_POST['id']."'";	
	$seres =	exequery($seqry);
	$serow  = fetch($seres);
	if($serow!=NULL){
		
	
		echo $serow['id']."#:#".YMDtoDMY($serow['date'])."#:#".$serow['time']."#:#".$serow['title']."#:#".$serow['matter']."#:#".$serow['tags'];
		echo "#@:@#";
		
		$qry1 = "SELECT fid,filepath FROM Newsfeeds1 WHERE id='".$serow['id']."'";
		//echo $qry1; 
		$res1 = exequery($qry1);
		while($row1 = fetch($res1)){
			echo $row1['filepath']."#:#".$row1['fid']."!#:#!";
		}
		

		
	}else{
		echo "NOTSEARCH";
	}
	

	die();
}

if($_POST['action'] == "Update")
{
	$id=$_POST['id'];
	
	$date=DMYtoYMD($_POST['date']);
	
	$time = $_POST['time'];
	
	$matter = $_POST['matter'];

	$title = $_POST['title'];
	
	$tags = $_POST['tags'];	
	
	$a = $_POST['a'];
	
	$qryup="UPDATE Newsfeeds SET date='".$date."', time = '".$time."', title = '".$title."', matter = '".$matter."', tags = '".$tags."'   WHERE id='".$id."'";
	
	exequery($qryup);
	
	
	    $maxqry = "select max(fid) from Newsfeeds1";
		$maxres = exequery($maxqry);
		$maxrow = fetch($maxres);
		if($maxrow[0]!=null)
		$idmax2=$maxrow[0]+1;	
		else{
			$idmax2 =1;
		}
	
	
	
	for($f=0; $f < $a; $f++)
		{
			//$fileParts=pathinfo($_FILES['fileattach0']['name']);
			if($_FILES['fileattach'.$f] !== ""){
				if ( 0 < $_FILES['fileattach'.$f]['error'] ){
					echo 'Error: ' . $_FILES['fileattach'.$f]['error'] . '<br>';
				}
				else{
					$fileParts = pathinfo($_FILES['fileattach'.$f]['name']);
					$attaddfile = 'NewsFeeds/'.$idmax.'_'.$idmax2.'_'.$f.'_'.$idmax2.'.'. $fileParts['extension'];;
					move_uploaded_file($_FILES['fileattach'.$f]['tmp_name'], $attaddfile);
					
				
					
					$qryin1 = "INSERT INTO Newsfeeds1 (fid, id, filepath) VALUES('".$idmax2."','".$id."','".$attaddfile."')";
					exequery($qryin1);
					
					
					
					$idmax2++;
				}
			}
		}
	
	
	
	
	
	echo "Update Succussfully";
	die();
}


if($_POST['action'] == "Delete"){

	$qrydel="DELETE FROM Newsfeeds WHERE id='".$_POST['id']."'";
	exequery($qrydel);
	
	
		$qrysel ="SELECT id,filepath FROM Newsfeeds1 WHERE id='".$_POST['id']."'";
		$ressel = exequery($qrysel);
		while($rowsel = fetch($ressel)){
		
		unlink($rowsel['filepath']);
		}
	
		$qrydel1="DELETE FROM Newsfeeds1 WHERE id='".$_POST['id']."'";
		exequery($qrydel1);

	
	echo "#:#DEL";
	die();
}



if($_POST['action'] == "loadgid1")
{
?>
	<table class="table" >
		<span style='float:right'><input class='btn' type='button' value='Back' name='Action' onclick='window.location.reload();'></span>
		<tr><th>ID</th><th>DATE</th><th>TIME</th><th>TITLE</th><th>MATTER</th><th>TAGS</th><th>FILEPATH</th></tr>
		<tbody>
		<?
			$qry = "select * from Newsfeeds order by id";
			$res = exequery($qry);
			while($rows = fetch($res))
			{
				
		?>		
			<tr>
				<td><a onclick="tableview(<? echo $rows[0]; ?>);" href="#"><? echo $rows[0]; ?></a></td>
				<td><? echo YMDtoDMY($rows[1]); ?></td>
				<td><? echo $rows[2]; ?></td>
				<td style='font-family:marathi; font-size:20px; text-align: justify;' ><? echo $rows[3]; ?></td>
				<td style='font-family:marathi; font-size:20px; text-align: justify;' ><? echo $rows[4]; ?></td>
				<td><? echo $rows[5]; ?></td>				
				<td>
				<table>
				<?
					$qry2="SELECT * FROM Newsfeeds1 where id='".$rows[0]."'";
					$res2= exequery($qry2);
					while($rows2=fetch($res2))
					{
						echo "<tr><td>".$rows2[2]."</td></tr>"; 
					}
				?>
				</table>
				</td>
			
			</tr>
		
		<?
			}
		
		?>
		</tbody>
	</table>
	
<?	
die();
}
?>

<? include('headerfeeds.php');
 //include('headerorg.php'); ?>
<style>
@font-face {
font-family:'marathi';
src: local('TBDTarun2'),
	local('TBDTarun2'),
	url('/tbdtaru2.ttf') format('truetype');
}
.marathilanguage {font-family:'marathi'; font-size:32};
.englishlanguage {font-size:16; font-family:"arial",arial,serif;};
</style>





<div class="well" style='border-top: Solid 4px #cc470d;margin-top:4%;'>
<div class="panel panel-default" style="width:100%;" id='mainform'>
<div class="panel-heading"><center><h3><a href="#" style='color:#cc470d;font-size:24px;text-align:left'>&nbsp;&nbsp;NEWS FEEDS</a></h3></center></div>
<div class="panel-body">
	  <div class="row" >
			<div class="row" >
			<div class="col-sm-12">
				<div class="form-group">
				<label class='control-label col-sm-2'>ID</label>
				<div class="col-sm-1">
				<?
				
					$qry="select max(id) from Newsfeeds";
					//echo $qry;
					$result=exequery($qry);
					$rowidno=fetch($result);
					if($rowidno!=null)
					$idno=$rowidno[0]+1;
				
				?>
				<input type="text" class="form-control" id="id" value="<?echo $idno;?>">
				</div>
				<button class="btn" type="button" id='LookUpbutton' name='LookUpbutton' value='LookUp' onclick='LookUp();'>Lookup</button>
				</div>
				
			</div>	
			</div>	
				
				
			<div class="row" >
			<div class="col-sm-12">
			
				<div class="form-group">
				<label class='control-label col-sm-2'>DATE </label>
				<div class="col-sm-4">
						<input type="text" class="form-control" id="date" name="date" placeholder="DATE" >
				</div><br><br>
				</div>
			</div>
			</div>
				
			<div class="row" >
			<div class="col-sm-12">	
				<div class="form-group">
				<label class='control-label col-sm-2'>TITLE </label>
				<div class="col-sm-4">
						<input type="text" class="form-control" id="title"  style='font-family:marathi; font-size:30px;'   name="title" placeholder="bhrby" >
				</div><br><br>
				</div>
			</div>
			</div>
				
				
				
				<div class="row" >
			<div class="col-sm-12">
				<div  style='form-group'  >
					<div class="form-group" >
					<label class='control-label col-sm-2'>TIME</label>
					<div class="col-sm-4">
					<input type="text" class="form-control" id="time" name="time" placeholder="TIME" >
					</div><br><br>
					</div>
				</div>
				</div></div>
				
				
				<div class="row" >
				<div class="col-sm-12">
				<div class="form-group">
				<label class='control-label col-sm-2'>MATTER</label>
				<div class="col-sm-4">
				<link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
				<link href="http://netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
				<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
				<script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>
			
				<link href="editor.css" type="text/css" rel="stylesheet"/>
				<script src="editor.js"></script>
					<textarea  style='font-family:marathi; font-size:20px;' id="txtEditor" cols='60' rows='8'  ></textarea>
				
				<script type="text/javascript">
				$(document).ready( function() {

				$("#txtEditor").Editor();                   

				});
				</script>
				</div>
				</div>
			<!--	<div class="form-group">
					<label class='control-label col-sm-2'>MATTER</label>
				<div class="col-sm-4">
				<textarea  class="form-control" id="matter" rows="3"  style='font-family:marathi; font-size:30px;'  name="matter" placeholder='Ah{bt'></textarea>
				</div>
				</div>
				-->
				</div>
				</div>
				
				
				
		
			<div class="row" >
			<div class="col-sm-12">
		
				<br><br><div class="form-group">
				<label class='control-label col-sm-2'>BROWSE</label>
				<div class="col-sm-4">
				<input type='file' class="form-control" id='attach0' name='attacho0'>
				<input  type='hidden' id='attachid' name='attachid' value='1'/>
				</div>
				
				<div class='col-md-2 col-sm-2'><a  title="" class="btn" onclick="attachfile();">+</a></div>
				

				</div>
				
			</div>	
			</div>

				
		
			<div class="row" >
			<div class="col-sm-12">
			
			<div class="form-group">
				<label class='control-label col-sm-2'></label>
				<div class='col-md-3 col-sm-3' id='attachfilediv'>	
				</div>
				<div class='col-md-3 col-sm-3' id='attachfilediv_p'>	
				</div>
			</div>
			
			</div>
			</div>
			
			
			<div class="row" >
			
			<div class="col-sm-12">
			
			<div class="form-group">
				<br><br><label class='control-label col-sm-2'>tags</label>
				<div class="col-sm-4">
				<textarea  class="form-control" id="tags" rows="2" name="tags" ></textarea>
				</div>
				</div>
	
			</div>
			</div>
			
			<div class="row" >
			<div class="col-sm-12">
			<div class="col-sm-2"></div>
			<div class="col-sm-10"><br><br>
				&nbsp;&nbsp;&nbsp;<button type="button" class="btn" type="button" id='AddUpdate' name='AddUpdate' value='Add' onclick='AddorUpdate();'>Add</button>
				<button type="button" class="btn" id='DeleteSearch' name='DeleteSearch' value='Search' onclick='SearchDelete();'>Search</button>
				<button type="button" class="btn" id='cancel' name='cancel' value='cancel' onclick="window.location = 'NewsFeedsMaster.php'">Cancel</button>
			
			</div>
			</div>
			</div>

	  
	  </div>
</div>

</div>
<div id='loadgid'></div>	
</div>
		</div>
	</div>
</div>

</body>
<link href="DatePickerAuditData/jquery-ui.css" rel="stylesheet">
			<script src="DatePickerAuditData/jquery-ui.js"></script>
			<script type="text/javascript">
			$(function() {
				$( "#date" ).datepicker({
					
				});
			});
			</script>
<script>
function AddorUpdate()
{	
		
		
		var btype = $('#AddUpdate').val();
		var id = $('#id').val();
		if(id == ''){			
		alert("Id Can't Be Empty!!!");
		return false;
		}
		
		
		
		var date = $('#date').val();
		var vtodate=isDate(date);
		if(vtodate===false){
		$('#date').focus();
		alert('Properly Select Date');
	    return false;
		}
		
		
		
		var title = $('#title').val();
		if(title == ''){
			
		alert("Title Can't Be Empty!!!");
		return false;
		}
		
		var time = $('#time').val();
		if(time == ''){
			
		alert("Time Can't Be Empty!!!");
		return false;
		}
		
		
		var	matter = $('.Editor-editor').html();
		if(matter == ''){
			
		alert("Matter Can't Be Empty!!!");
		return false;
		}
		
		//alert(matter);
		//return false;
		
		var	tags = $('#tags').val();	
		if(tags == ''){			
		alert("Tags Can't Be Empty!!!");
		return false;
		}
	
	
		var formData = new FormData();
		var ait = $('#attachid').val();
		var a=0;
		for (var f=0; f<ait; f++){
			
			var attaddfile = $('#attach'+f).prop('files')[0];
	
			if(jQuery.type(attaddfile) !== "undefined"){
				formData.append('fileattach'+a, attaddfile);
				a++;
			}	
		}	
		
		//alert('hi');
		
		formData.append('a', a);
		formData.append('id', id);
		formData.append('date', date);
		formData.append('time', time);
		formData.append('title', title);
		formData.append('matter', matter);
		formData.append('tags', tags);
		formData.append('action', btype);
		
	$.ajax({
		url:"NewsFeedsMaster.php",
		type:"POST",
		data : formData,
		processData: false, 
		contentType: false,  
		
		success:function(output)
		{
			alert($.trim(output));
			window.location.reload();
		}
		
		});
	
	
	
}
function SearchDelete()
{
 
		 var id=$('#id').val();
		 var Search=$('#DeleteSearch').val();
		 
		 
		 
		 $.ajax({
			url:"NewsFeedsMaster.php",																	
			data:"action="+Search+"&id="+id,
			type:"POST",
			success:function(output)
			{
					var result=output.split('#@:@#');	
					var store=result[0].split('#:#');
					if(store[0]=="NOTSEARCH"){
					 alert("Record Not Found");
					 return false
					}
					
					 if(store[1] == "DEL"){
				    alert("Record Deleted ...!!")
				    location.reload(true);
				   return false
			      }
					
				
				 $('#id').val(store[0]);
				 $('#date').val(store[1]);
				 $('#time').val(store[2]);
				 $('#title').val(store[3]);
				 $('.Editor-editor').html(store[4]);
				 $('#tags').val(store[5]);
				
				var store1 = result[1].split('!#:#!');
				var count = store1.length;
				 
			   	 $('#attachfilediv_p').html('');
				 
					for(var p=0; p<(count - 1); p++){
						
						var store3 = store1[p].split('#:#');
						var v = parseInt(p) + 1;
						$('#attachfilediv_p').append("<div id='attachfilediv_p"+store3[1]+"'><a href='"+store3[0]+"' target='_blank' class='btn'>Attachment"+v+"</a><a class='btn' type='button' onclick='deletefile("+store3[1]+","+store[0]+");'>delete </a><div> </br>");
					}
				
				 $('#DeleteSearch').val('Delete');
				 $('#DeleteSearch').html('Delete');
				 
				 $('#AddUpdate').val('Update');
				 $('#AddUpdate').html('Update');
			 //alert(output);	
			}
		 });
	 
}

function LookUp()
{
 $("#loadgid").show();
	$.ajax({
		url:"NewsFeedsMaster.php",
		type:"POST",
		data : "action=loadgid1",
		success:function(output)
		{
			 $('#loadgid').html(output);
			 $("#mainform").hide();
			return false;
		}
		
		});
}

function  tableview(id)
{
		$('#id').val(id);
		$("#mainform").show();
		$("#loadgid").hide();
		$('#DeleteSearch').val('Search');
		$('#DeleteSearch').html('Search');
		SearchDelete();
}


function deletefile(fid,id){
		
		var r = confirm("Are You Sure You Want To Delete...!!!");
		if(r == true){
			$.ajax({
				url:"NewsFeedsMaster.php",
				data:"action=deletefile&fileid="+fid,
				type:"POST",
				success:function(output){
					//alert($.trim(output));
					if($.trim(output) == 'del'){
						alert("File is Deleted..!!!");
					    
						$('#attachfilediv_p'+fid).hide();
						
					}
					else{
						//$.trim(output);
					}
					
				}
			});	
		}		
	}


function attachfile()
	{
		var aid = $('#attachid').val();
		$('#attachfilediv').append("<input type='file' id='attach"+aid+"' name='attach"+aid+"' class='form-control' />");
		aid++;
		$('#attachid').val(aid);
	}
	
	
function isDate(txtDate)
{

	  var currVal = txtDate;

	  if(currVal == '')

	    return false;

	   

	  //Declare Regex 

	  var rxDatePattern = /^(\d{1,2})(\/|-)(\d{1,2})(\/|-)(\d{4})$/;

	  var dtArray = currVal.match(rxDatePattern); // is format OK?

	 

	  if (dtArray == null)

	     return false;

	  

	  //Checks for mm/dd/yyyy format.

	  dtDay   = dtArray[1];

	  dtMonth = dtArray[3];

	  dtYear = dtArray[5];

	 

	  if (dtMonth < 1 || dtMonth > 12)

	      return false;

	  else if (dtDay < 1 || dtDay> 31)

	      return false;

	  else if ((dtMonth==4 || dtMonth==6 || dtMonth==9 || dtMonth==11) && dtDay ==31)

	      return false;

	  else if (dtMonth == 2)

	  {

	     var isleap = (dtYear % 4 == 0 && (dtYear % 100 != 0 || dtYear % 400 == 0));

	     if (dtDay> 29 || (dtDay ==29 && !isleap))

	          return false;

	  }

	  return true;

}

	
</script>